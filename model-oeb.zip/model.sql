# <model>
# 			<lodelversion>1.0</lodelversion>
# 			<date>2019-12-12</date>
# 			<title>
# 			oeb editorial model
# 			</title>
# 			<description>
# 			oeb editorial model
# 			</description>
# 			<author>
# 			openedition
# 			</author>
# 			<modelversion>
# 			1.0.0
# 			</modelversion>
# 			</model>
# 			
#------------

DELETE FROM #_TP_classes;
DELETE FROM #_TP_tablefields;
DELETE FROM #_TP_tablefieldgroups;
DELETE FROM #_TP_types;
DELETE FROM #_TP_persontypes;
DELETE FROM #_TP_entrytypes;
DELETE FROM #_TP_entitytypes_entitytypes;
DELETE FROM #_TP_characterstyles;
DELETE FROM #_TP_internalstyles;
# # Database: 'lodelbooks_me-books-dist'# 
#
# Dumping data for table 'classes'
#

INSERT INTO #_TP_classes (id, icon, class, title, altertitle, classtype, comment, rank, status, upd) VALUES (255, 'lodel/icons/texte.gif', 'textes', 'Textes', '<r2r:ml lang="en">Texts</r2r:ml><r2r:ml lang="pt">Textos</r2r:ml><r2r:ml lang="es">Textos</r2r:ml>', 'entities', '', 2, 32, '2013-04-11 15:08:08'),
(256, 'lodel/icons/collection.gif', 'publications', 'Publications', '<r2r:ml lang="en">Folders</r2r:ml><r2r:ml lang="pt">Publicações</r2r:ml><r2r:ml lang="es">Publicaciones</r2r:ml>', 'entities', '', 1, 1, '2013-04-11 15:08:19'),
(257, 'lodel/icons/doc_annexe.gif', 'fichiers', 'Fichiers', '<r2r:ml lang="en">Files</r2r:ml><r2r:ml lang="pt">Ficheiros</r2r:ml><r2r:ml lang="es">Archivos</r2r:ml>', 'entities', '', 5, 32, '2013-04-11 15:14:31'),
(258, 'lodel/icons/lien.gif', 'liens', 'Sites', '<r2r:ml lang="en">Websites</r2r:ml><r2r:ml lang="pt">Websites</r2r:ml><r2r:ml lang="es">Sitios web</r2r:ml>', 'entities', '', 6, 32, '2013-04-11 15:16:33'),
(259, 'lodel/icons/texte_simple.gif', 'textessimples', 'Textes simples', '<r2r:ml lang="en">Simple texts</r2r:ml><r2r:ml lang="pt">Textos simples</r2r:ml><r2r:ml lang="es">Textos simples</r2r:ml>', 'entities', '', 3, 32, '2013-04-11 15:08:41'),
(260, 'lodel/icons/personne.gif', 'auteurs', 'Auteurs', '<r2r:ml lang="en">Authors</r2r:ml><r2r:ml lang="pt">Autores</r2r:ml><r2r:ml lang="es">Autores</r2r:ml>', 'persons', '', 8, 32, '2013-04-16 11:07:24'),
(261, 'lodel/icons/index.gif', 'indexes', 'Index', '<r2r:ml lang="en">Indexes</r2r:ml><r2r:ml lang="pt">Índices</r2r:ml><r2r:ml lang="es">Índices</r2r:ml>', 'entries', '', 9, 1, '2013-04-16 11:06:01'),
(262, 'lodel/icons/individu.gif', 'individus', 'Personnes', '<r2r:ml lang="en">Persons</r2r:ml><r2r:ml lang="pt">Indivíduos</r2r:ml><r2r:ml lang="es">Individuos</r2r:ml>', 'entities', '', 4, 1, '2013-04-11 15:11:39'),
(263, 'lodel/icons/doc_annexe.gif', 'fichiersexternes', 'Fichiers distants', '<r2r:ml lang="pt">Ficheiros externos</r2r:ml><r2r:ml lang="en">Remote files</r2r:ml><r2r:ml lang="es">Archivos externos</r2r:ml>', 'entities', '', 11, 32, '2013-04-11 15:19:14'),
(267, 'lodel/icons/lien.gif', 'modulesaffichage', 'Modules d\'affichage', '<r2r:ml lang="es">Módulos de visualización</r2r:ml>', 'entities', '', 16, 1, '2013-04-11 15:20:21'),
(625, 'lodel/icons/index.gif', 'funder', 'Funder Registry', '', 'entries', '', 19, 32, '2019-07-05 12:24:40');

#
# Dumping data for table 'tablefields'
#

INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, altertitle, style, type, g_name, cond, defaultvalue, processing, allowedtags, gui_user_complexity, filtering, edition, editionparams, editionhooks, weight, comment, mask, status, rank, otx, upd) VALUES (1, 'titre', 1, 'textes', 'Titre du document', '<r2r:ml lang="en">Document title</r2r:ml><r2r:ml lang="pt">Título do documento</r2r:ml><r2r:ml lang="es">Título del documento</r2r:ml>', 'title, titre, titleuser, heading', 'text', 'dc.title', '+', 'Document sans titre', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;Lien;Appel de Note;style:strict', 16, '', 'editable', '', 'post:indexentity_post,post:generatePdfEpub', 8, '', '', 1, 3, '/tei:TEI/tei:teiHeader/tei:fileDesc/tei:titleStmt/tei:title[@type=\'main\']', '2019-09-20 11:34:07'),
(2, 'surtitre', 1, 'textes', 'Surtitre du document', '<r2r:ml lang="en">Document heading (additional title)</r2r:ml><r2r:ml lang="pt">Antetítulo do documento</r2r:ml><r2r:ml lang="es">Antetítulo del documento</r2r:ml>', 'surtitre,subhead', 'text', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;Lien;Appel de Note;style:strict', 32, '', 'importable', '', '', 8, '', '', 1, 2, '/tei:TEI/tei:teiHeader/tei:fileDesc/tei:titleStmt/tei:title[@type=\'sup\']', '2018-06-06 12:09:02'),
(3, 'soustitre', 1, 'textes', 'Sous-titre du document', '<r2r:ml lang="en">Document subtitle (secondary title)</r2r:ml><r2r:ml lang="pt">Subtítulo do documento</r2r:ml><r2r:ml lang="es">Subtítulo del documento</r2r:ml>', 'subtitle, soustitre', 'text', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;Lien;Appel de Note;style:strict', 32, '', 'editable', '', '', 8, '', '', 1, 5, '/tei:TEI/tei:teiHeader/tei:fileDesc/tei:titleStmt/tei:title[@type=\'sub\']', '2014-01-30 14:38:06'),
(4, 'texte', 2, 'textes', 'Texte du document', '<r2r:ml lang="en">Standard text</r2r:ml><r2r:ml lang="pt">Texto do documento</r2r:ml><r2r:ml lang="es">Texto del documento</r2r:ml>', 'texte, standard, normal, textbody', 'longtext', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;xhtml:block;Lien;Appel de Note', 16, '', 'display', '', '', 4, '', '', 32, 1, '/tei:TEI/tei:text/tei:body/child::*', '2013-04-15 10:39:45'),
(5, 'notesbaspage', 2, 'textes', 'Notes de bas de page', '<r2r:ml lang="en">Footnotes</r2r:ml><r2r:ml lang="pt">Notas de rodapé</r2r:ml><r2r:ml lang="es">Notas de pie de página</r2r:ml>', 'notebaspage, footnote, footnotetext,footnotes', 'longtext', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;xhtml:block;Lien', 32, '', 'importable', '', '', 4, '', '', 1, 2, '', '2018-06-06 12:09:02'),
(7, 'annexe', 2, 'textes', 'Annexes du document', '<r2r:ml lang="en">Appendixes</r2r:ml><r2r:ml lang="pt">Anexos ao documento</r2r:ml><r2r:ml lang="es">Anexos del documento</r2r:ml>', 'annexe,appendix', 'longtext', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;xhtml:block;Lien;Appel de Note', 32, '', 'importable', '', '', 4, '', '', 1, 4, '/tei:TEI/tei:text/tei:back/tei:div[@type=\'appendix\']', '2018-06-06 12:09:02'),
(8, 'bibliographie', 2, 'textes', 'Bibliographie du document', '<r2r:ml lang="en">Bibliography</r2r:ml><r2r:ml lang="pt">Bibliografia</r2r:ml><r2r:ml lang="es">Bibliografía</r2r:ml>', 'bibliographie,bibliography,bibliografia', 'longtext', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;xhtml:block;Lien;Appel de Note', 32, '', 'importable', '', '', 4, '', '', 1, 5, '/tei:TEI/tei:text/tei:back/tei:div[@type=\'bibliography\']', '2019-09-20 11:32:12'),
(12, 'pagination', 3, 'textes', 'Pagination du document sur le papier', '<r2r:ml lang="en">Pagination</r2r:ml><r2r:ml lang="pt">Números de página do documento em papel</r2r:ml><r2r:ml lang="es">Paginación del documento en papel</r2r:ml>', 'pagination,pagenumbering', 'tinytext', '', '*', '', '', ';style:none', 64, '', 'editable', '', '', 0, '', '', 1, 2, '/tei:TEI/tei:teiHeader/tei:fileDesc/tei:sourceDesc/tei:biblFull/tei:publicationStmt/tei:idno[@type=\'pp\']', '2018-06-06 12:09:02'),
(14, 'langue', 3, 'textes', 'Langue du document', '<r2r:ml lang="en">Language of document</r2r:ml><r2r:ml lang="pt">Língua do documento</r2r:ml><r2r:ml lang="es">Idioma del documento</r2r:ml>', 'langue,language', 'lang', 'dc.language', '*', '', '', ';style:none', 32, '', 'editable', '', '', 0, '', '', 1, 3, '/tei:TEI/tei:teiHeader/tei:profileDesc/tei:langUsage/tei:language', '2018-06-06 12:09:02'),
(15, 'prioritaire', 16, 'textes', 'Document prioritaire', '<r2r:ml lang="en">Document priority</r2r:ml><r2r:ml lang="pt">Documento prioritário</r2r:ml><r2r:ml lang="es">Documento prioritario</r2r:ml>', '', 'boolean', '', '*', '', '', '', 64, '', 'editable', '', '', 0, '', '', 32, 7, '', '2013-04-15 10:50:49'),
(17, 'addendum', 4, 'textes', 'Addendum', '<r2r:ml lang="pt">Adenda</r2r:ml><r2r:ml lang="en">Addendum</r2r:ml><r2r:ml lang="es">Addendum</r2r:ml>', 'erratum, addendum', 'text', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;xhtml:block;Lien;Appel de Note', 64, '', 'importable', '', '', 2, '', '', 32, 3, '/tei:TEI/tei:text/tei:front/tei:div[@type=\'correction\']', '2013-04-12 17:32:44'),
(18, 'ndlr', 4, 'textes', 'Note de la rédaction', '<r2r:ml lang="en">Editor\'s note</r2r:ml><r2r:ml lang="pt">Nota de edição</r2r:ml><r2r:ml lang="es">Nota de la redacción</r2r:ml>', 'ndlr,editorsnote', 'text', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;xhtml:block;Lien;Appel de Note', 64, '', 'importable', '', '', 2, '', '', 1, 1, '/tei:TEI/tei:text/tei:front/tei:note[@resp=\'editor\']/tei:p', '2018-06-06 12:09:02'),
(20, 'commentaireinterne', 16, 'textes', 'Commentaire interne sur le document', '<r2r:ml lang="en">Internal comment about the document</r2r:ml><r2r:ml lang="pt">Comentário interno sobre o documento</r2r:ml><r2r:ml lang="es">Comentario interno sobre el documento</r2r:ml>', 'commentaire', 'text', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;xhtml:block;Lien', 64, '', 'importable', '', '', 0, '', '', 32, 4, '', '2013-04-15 10:50:23'),
(21, 'dedicace', 4, 'textes', 'Dédicace', '<r2r:ml lang="en">Dedication</r2r:ml><r2r:ml lang="pt">Dedicatória</r2r:ml><r2r:ml lang="es">Dedicatoria</r2r:ml>', 'dedicace,dedication', 'text', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;xhtml:block;Lien;Appel de Note', 64, '', 'importable', '', '', 2, '', '', 1, 4, '/tei:TEI/tei:text/tei:front/tei:div[@type=\'dedication\']', '2018-06-06 12:09:02'),
(24, 'documentcliquable', 16, 'textes', 'Document cliquable dans les sommaires', '<r2r:ml lang="en">The document is clickable in the contents of the folder</r2r:ml><r2r:ml lang="pt">Documento clicável no índice</r2r:ml><r2r:ml lang="es">Documento con enlaces en el índice</r2r:ml>', '', 'boolean', '', '*', 'true', '', '', 64, '', 'editable', '', '', 0, '', '', 32, 10, '', '2013-04-15 11:09:47'),
(25, 'nom', 0, 'indexes', 'Dénomination de l’entrée d’index', '<r2r:ml lang="en">Entry name</r2r:ml><r2r:ml lang="pt">Designação da entrada do índice</r2r:ml>', '', 'text', 'index key', '*', '', '', '', 16, '', 'editable', '', '', 4, '', '', 32, 25, '', '2012-11-14 10:34:56'),
(26, 'motsclesfr', 15, 'textes', 'Mots-clés', '<r2r:ml lang="es">Mots-clés</r2r:ml><r2r:ml lang="en">Mots-clés</r2r:ml><r2r:ml lang="de">Mots-clés</r2r:ml><r2r:ml lang="fr">Mots-clés</r2r:ml><r2r:ml lang="it">Mots-clés</r2r:ml><r2r:ml lang="pt">Mots-clés</r2r:ml>', '', 'entries', '', '', '', '', '', 64, '', 'importable', '', '', 0, '', '', 32, 1, '', '2019-07-05 12:08:25'),
(27, 'definition', 0, 'indexes', 'Définition', '<r2r:ml lang="en">Entry definition</r2r:ml><r2r:ml lang="pt">Definição da entrada do índice</r2r:ml>', '', 'text', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;xhtml:block;Lien', 16, '', 'fckeditor', 'Basic', '', 1, '', '', 32, 27, '', '2012-03-21 14:52:01'),
(28, 'nomfamille', 0, 'auteurs', 'Nom de famille', '<r2r:ml lang="en">Surname</r2r:ml><r2r:ml lang="pt">Apelido</r2r:ml>', '', 'tinytext', 'familyname', '*', '', '', '', 32, '', 'editable', '', '', 4, '', '', 32, 28, '', '2012-03-21 14:34:25'),
(29, 'prenom', 0, 'auteurs', 'Prénom', '<r2r:ml lang="en">Name</r2r:ml><r2r:ml lang="pt">Nome próprio</r2r:ml>', '', 'tinytext', 'firstname', '*', '', '', '', 32, '', 'editable', '', '', 4, '', '', 32, 29, '', '2012-03-21 14:52:01'),
(30, 'prefix', 0, 'entities_auteurs', 'Préfixe', '<r2r:ml lang="en">Prefix</r2r:ml><r2r:ml lang="pt">Título</r2r:ml>', 'prefixe, .prefixe', 'tinytext', '', '*', '', '', '', 64, '', 'editable', '', '', 0, '', '', 1, 2, '//tei:roleName[@type=\'honorific\']', '2012-03-21 14:52:01'),
(31, 'affiliation', 0, 'entities_auteurs', 'Affiliation', '<r2r:ml lang="en">Affiliation</r2r:ml><r2r:ml lang="pt">Afiliação</r2r:ml>', 'affiliation, .affiliation', 'tinytext', '', '*', '', '', '', 32, '', 'editable', '', '', 4, '', '', 1, 3, '//tei:orgName', '2012-03-21 14:52:01'),
(32, 'fonction', 0, 'entities_auteurs', 'Fonction', '<r2r:ml lang="en">Function</r2r:ml><r2r:ml lang="pt">Função</r2r:ml>', 'fonction, .fonction', 'tinytext', '', '*', '', '', '', 32, '', 'editable', '', '', 0, '', '', 1, 4, '//tei:roleName[@type=\'function\']', '2012-03-21 14:52:01'),
(33, 'description', 0, 'entities_auteurs', 'Description de l’auteur', '<r2r:ml lang="en">Author description</r2r:ml><r2r:ml lang="pt">Apresentação do autor</r2r:ml>', 'descriptionauteur,authordescription', 'text', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;xhtml:block;Lien', 16, '', 'fckeditor', '5', '', 4, '', '', 1, 1, '//tei:affiliation', '2018-06-06 12:09:02'),
(34, 'courriel', 0, 'entities_auteurs', 'Courriel', '<r2r:ml lang="en">Email</r2r:ml><r2r:ml lang="pt">E-mail</r2r:ml>', 'courriel, .courriel', 'email', '', '*', '', '', '', 32, '', 'editable', '', '', 4, '', '', 1, 5, '//tei:email', '2012-03-21 14:34:25'),
(35, 'auteur', 14, 'textes', 'Auteur du document', '<r2r:ml lang="en">Author</r2r:ml><r2r:ml lang="pt">Autor do documento</r2r:ml><r2r:ml lang="es">Autor del documento</r2r:ml>', '', 'persons', '', '', '', '', '', 64, '', 'editable', '', '', 0, '', '', 32, 11, '', '2013-04-12 16:46:49'),
(36, 'traducteur', 14, 'textes', 'Traducteur du document', '<r2r:ml lang="en">Translator</r2r:ml><r2r:ml lang="pt">Tradutor do documento</r2r:ml><r2r:ml lang="es">Traductor del documento</r2r:ml>', '', 'persons', '', '', '', '', '', 64, '', 'editable', '', '', 0, '', '', 32, 12, '', '2013-04-12 16:47:12'),
(43, 'titre', 5, 'liens', 'Titre du site', '<r2r:ml lang="en">Website title</r2r:ml><r2r:ml lang="pt">Título do website</r2r:ml><r2r:ml lang="es">Título del sitio web</r2r:ml>', '', 'text', 'dc.title', '*', 'Site sans titre', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;Appel de Note', 16, '', 'editable', '', 'post:indexentity_post', 8, '', '', 1, 43, '', '2019-09-20 11:34:07'),
(44, 'url', 6, 'liens', 'URL du site', '<r2r:ml lang="en">Website URL</r2r:ml><r2r:ml lang="pt">URL do website</r2r:ml><r2r:ml lang="es">URL del sitio</r2r:ml>', '', 'url', '', '*', '', '', '', 16, '', 'editable', '', '', 0, '', '', 32, 1, '', '2013-04-15 16:50:07'),
(45, 'urlfil', 6, 'liens', 'URL du fil de syndication du site', '<r2r:ml lang="en">RSS feed URL</r2r:ml><r2r:ml lang="pt">URL do feed RSS do website</r2r:ml><r2r:ml lang="es">URL del flujo de sindicación del sitio web</r2r:ml>', '', 'url', '', '*', '', '', '', 16, '', 'editable', '', '', 0, '', '', 32, 4, '', '2013-04-16 12:36:11'),
(46, 'texte', 6, 'liens', 'Description du site', '<r2r:ml lang="en">Website synopsis</r2r:ml><r2r:ml lang="pt">Sinopse do website</r2r:ml><r2r:ml lang="es">Descripción del sitio web</r2r:ml>', '', 'text', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;xhtml:block;Lien;Appel de Note', 16, '', 'fckeditor', 'Simple', '', 2, '', '', 32, 2, '', '2013-04-15 16:51:05'),
(47, 'titre', 7, 'fichiers', 'Titre', '<r2r:ml lang="en">Title</r2r:ml><r2r:ml lang="pt">Título</r2r:ml><r2r:ml lang="es">Título</r2r:ml>', '', 'text', 'dc.title', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;Appel de Note', 16, '', 'editable', '', 'post:indexentity_post,post:generatePdfEpub,post:update_cover', 4, '', '', 1, 47, '', '2019-09-20 11:34:07'),
(48, 'document', 8, 'fichiers', 'Document', '<r2r:ml lang="en">Document</r2r:ml><r2r:ml lang="pt">Documento</r2r:ml><r2r:ml lang="es">Documento</r2r:ml>', '', 'file', '', '*', '', '', '', 16, '', 'editable', '', '', 0, '', '', 1, 1, '', '2019-09-20 11:34:07'),
(50, 'resume', 9, 'textes', 'Résumé', '<r2r:ml lang="en">Abstract</r2r:ml><r2r:ml lang="pt">Resumo</r2r:ml><r2r:ml lang="es">Resumen</r2r:ml>', 'rsum:fr,resume:fr,resumefr:fr,abstract:en,resumeen:en,extracto:es,resumen:es, resumees:es,resumo:pt,resumept:pt,riassunto:it,resumeit:it,zusammenfassung:de,resumede:de,resumeru:ru,resumear:ar', 'mltext', 'dc.description', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;xhtml:block;Lien;Appel de Note', 16, '', 'display', '5', '', 8, '', '', 32, 50, '/tei:TEI/tei:text/tei:front/tei:div[@type=\'abstract\']', '2013-04-12 16:48:52'),
(51, 'titre', 10, 'publications', 'Titre de la publication', '<r2r:ml lang="en">Folder title</r2r:ml><r2r:ml lang="pt">Título da publicação</r2r:ml><r2r:ml lang="es">Título de la publicación</r2r:ml>', '', 'text', 'dc.title', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;Appel de Note', 16, '', 'editable', '', 'pre:bisac_map_to_bic_pre,post:indexentity_post,post:generatePdfEpub,post:update_cover', 8, '', '', 1, 2, '', '2019-09-20 11:34:07'),
(52, 'surtitre', 10, 'publications', 'Surtitre de la publication', '<r2r:ml lang="en">Folder heading (additional title)</r2r:ml><r2r:ml lang="pt">Antetítulo da publicação</r2r:ml><r2r:ml lang="es">Antetítulo de la publicación</r2r:ml>', '', 'text', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;Appel de Note', 16, '', 'importable', '', '', 8, '', '', 32, 1, '', '2013-04-11 16:24:03'),
(53, 'soustitre', 10, 'publications', 'Sous-titre de la publication', '<r2r:ml lang="en">Folder subtitle (secondary title)</r2r:ml><r2r:ml lang="pt">Subtítulo da publicação</r2r:ml><r2r:ml lang="es">Subtítulo de la publicación</r2r:ml>', '', 'text', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;Appel de Note', 16, '', 'editable', '', '', 8, '', '', 32, 3, '', '2013-04-11 16:36:47'),
(54, 'commentaireinterne', 11, 'publications', 'Commentaire interne sur la publication', '<r2r:ml lang="en">Internal comment about the folder</r2r:ml><r2r:ml lang="pt">Comentário interno sobre a publicação</r2r:ml><r2r:ml lang="es">Comentario interno sobre la publicación</r2r:ml>', '', 'text', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;xhtml:block;Lien', 64, '', 'editable', '4', '', 0, '', '', 32, 54, '', '2013-04-11 17:24:21'),
(55, 'prioritaire', 11, 'publications', 'Cette publication est-elle prioritaire ?', '<r2r:ml lang="en">The publication of the folder is having priority</r2r:ml><r2r:ml lang="pt">Esta publicação é prioritária?</r2r:ml><r2r:ml lang="es">¿Esta publicación es prioritaria?</r2r:ml>', '', 'boolean', '', '*', '', '', '', 16, '', 'editable', '', '', 0, '', '', 32, 55, '', '2013-04-12 12:30:20'),
(57, 'datepubli', 12, 'publications', 'Date de publication électronique', '<r2r:ml lang="en">Date of online publication (electronic edition)</r2r:ml><r2r:ml lang="pt">Data da publicação electrónica</r2r:ml><r2r:ml lang="es">Fecha de publicación electrónica</r2r:ml>', '', 'date', 'dc.date', '*', 'today', '', '', 16, '', 'editable', '', '', 0, '', '', 32, 5, '', '2013-04-11 16:17:12'),
(58, 'datepublipapier', 12, 'publications', 'Date de publication papier', '<r2r:ml lang="en">Date of publication (print edition)</r2r:ml><r2r:ml lang="pt">Data da publicação em papel</r2r:ml><r2r:ml lang="es">Fecha de publicación papel</r2r:ml>', '', 'date', '', '*', '', '', '', 16, '', 'editable', '', '', 0, '', '', 32, 6, '', '2013-04-11 16:17:51'),
(59, 'noticebiblio', 31, 'publications', 'Notice bibliographique décrivant la publication', '<r2r:ml lang="en">Bibliographical reference</r2r:ml><r2r:ml lang="pt">Referência bibliográfica da publicação</r2r:ml><r2r:ml lang="es">Referencia bibliográfica de la publicación</r2r:ml>', '', 'text', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special', 64, '', 'importable', '', '', 0, '', '', 32, 12, '', '2013-04-11 17:00:25'),
(60, 'introduction', 13, 'publications', 'Introduction de la publication', '<r2r:ml lang="fr">Introduction de la publication</r2r:ml><r2r:ml lang="en">Folder introduction</r2r:ml><r2r:ml lang="pt">Introdução à publicação</r2r:ml><r2r:ml lang="es">Introducción de la publicación</r2r:ml>', '', 'mltext', 'dc.description', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;xhtml:block;Lien;Appel de Note', 16, '', 'fckeditor', 'Simple,550,400', '', 8, '', '', 32, 1, '', '2013-04-11 17:02:01'),
(62, 'ndlr', 13, 'publications', 'Note de la rédaction au sujet de la publication', '<r2r:ml lang="en">Editor\'s note about the folder</r2r:ml><r2r:ml lang="pt">Nota editorial sobre a publicação</r2r:ml><r2r:ml lang="es">Nota editorial sobre la publicación</r2r:ml>', '', 'text', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;xhtml:block;Lien;Appel de Note', 64, '', 'fckeditor', '', '', 2, '', '', 32, 2, '', '2013-04-11 17:03:11'),
(63, 'historique', 13, 'publications', 'Historique de la publication', '<r2r:ml lang="en">Folder history</r2r:ml><r2r:ml lang="pt">Histórico da publicação</r2r:ml><r2r:ml lang="es">Histórico de la publicación</r2r:ml>', '', 'text', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;xhtml:block;Lien;Appel de Note', 64, '', 'importable', '', '', 0, '', '', 32, 3, '', '2013-04-11 17:03:37'),
(66, 'paraitre', 11, 'publications', 'Cette publication est-elle à paraître ?', '<r2r:ml lang="en">The publication of the folder is forthcoming</r2r:ml><r2r:ml lang="pt">Esta publicação está no prelo?</r2r:ml><r2r:ml lang="es">¿Esta publicación es de próxima aparición?</r2r:ml>', '', 'boolean', '', '*', '', '', '', 32, '', 'editable', '', '', 0, '', '', 32, 66, '', '2013-04-12 12:30:03'),
(67, 'integralite', 43, 'publications', 'Cette publication est-elle en libre accès ?', '<r2r:ml lang="en">The folder is published in full open access</r2r:ml><r2r:ml lang="pt">Esta publicação online é integral?</r2r:ml><r2r:ml lang="es">¿Esta publicación en línea es completa?</r2r:ml>', '', 'boolean', '', '*', '1', '', '', 32, '', 'editable', '', '', 0, '', '', 32, 1, '', '2013-11-13 15:11:34'),
(68, 'numero', 12, 'publications', 'Numéro de la publication', '<r2r:ml lang="en">Volume number</r2r:ml><r2r:ml lang="pt">Número da publicação</r2r:ml><r2r:ml lang="es">Número de la publicación</r2r:ml>', '', 'tinytext', '', '*', '', '', '', 16, '', 'editable', '', '', 0, '', '', 32, 7, '', '2013-04-11 16:18:31'),
(69, 'motsclesen', 15, 'textes', 'Keywords', '<r2r:ml lang="es">Keywords</r2r:ml><r2r:ml lang="de">Keywords</r2r:ml><r2r:ml lang="en">Keywords</r2r:ml><r2r:ml lang="fr">Keywords</r2r:ml><r2r:ml lang="it">Keywords</r2r:ml><r2r:ml lang="pt">Keywords</r2r:ml>', '', 'entries', '', '', '', '', '', 64, '', 'importable', '', '', 0, '', '', 32, 2, '', '2019-07-05 12:08:25'),
(74, 'altertitre', 1, 'textes', 'Titre alternatif du document (dans une autre langue)', '<r2r:ml lang="en">Document translated title (alternative title)</r2r:ml><r2r:ml lang="pt">Título traduzido do documento</r2r:ml><r2r:ml lang="es">Título traducido del documento (título alternativo)</r2r:ml>', 'titretraduitfr:fr,titrefr:fr,titretraduiten:en,titleen:en,titreen:en,titretraduites:es,tituloes:es,titrees:es,titretraduitit:it,titoloit:it,titreit:it,titretraduitde:de,titelde:de,titrede:de,titretraduitpt:pt,titrept:pt,titulopt:pt,titreru:ru', 'mltext', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;Lien;Appel de Note;style:strict', 16, '', 'editable', '', '', 8, '', '', 1, 4, '/tei:TEI/tei:teiHeader/tei:fileDesc/tei:titleStmt/tei:title[@type=\'alt\']', '2014-01-30 14:38:06'),
(76, 'titreoeuvre', 17, 'textes', 'Titre de l’œuvre commentée', '<r2r:ml lang="en">Title of the reviewed document</r2r:ml><r2r:ml lang="pt">Título da obra comentada</r2r:ml><r2r:ml lang="es">Título de la obra comentada</r2r:ml>', 'titreoeuvre', 'text', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;Appel de Note;style:strict', 64, '', 'display', '', '', 4, '', '', 1, 2, '/tei:TEI/tei:text/tei:front/tei:div[@type=\'review\']/tei:p[@rend=\'review-title\']', '2014-01-30 14:38:06'),
(77, 'noticebibliooeuvre', 17, 'textes', 'Notice bibliographique de l’œuvre commentée', '<r2r:ml lang="en">Bibliographical reference describing the reviewed document</r2r:ml><r2r:ml lang="pt">Referência bibliográfica da obra comentada</r2r:ml><r2r:ml lang="es">Referencia bibliográfica de la obra comentada</r2r:ml>', 'noticebibliooeuvre', 'text', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;xhtml:block;Appel de Note;style:strict', 64, '', 'display', '', '', 4, '', '', 1, 1, '/tei:TEI/tei:text/tei:front/tei:div[@type=\'review\']/tei:p[@rend=\'review-bibliography\']', '2014-01-30 14:38:06'),
(78, 'datepublicationoeuvre', 17, 'textes', 'Date de publication de l’œuvre commentée', '<r2r:ml lang="en">Date of publication of the reviewed document</r2r:ml><r2r:ml lang="pt">Data de publicação da obra comentada</r2r:ml><r2r:ml lang="es">Fecha de publicación de la obra comentada</r2r:ml>', 'datepublioeuvre', 'tinytext', '', '*', '', '', ';style:none', 64, '', 'display', '', '', 4, '', '', 1, 70, '/tei:TEI/tei:text/tei:front/tei:div[@type=\'review\']/tei:p[@rend=\'review-date\']', '2014-01-30 14:38:06'),
(79, 'auteuroeuvre', 17, 'textes', 'Auteur de l’œuvre commentée', '<r2r:ml lang="en">Author of the reviewed document</r2r:ml><r2r:ml lang="pt">Autor da obra comentada</r2r:ml><r2r:ml lang="es">Autor de la obra comentada</r2r:ml>', '', 'persons', '', '', '', '', '', 64, '', 'editable', '', '', 0, '', '', 32, 71, '', '2013-04-12 17:48:22'),
(81, 'titre', 18, 'textessimples', 'Titre', '<r2r:ml lang="en">Title</r2r:ml><r2r:ml lang="pt">Título</r2r:ml><r2r:ml lang="es">Título</r2r:ml>', '', 'tinytext', 'dc.title', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;xhtml:block;Lien;Appel de Note', 16, '', 'editable', '', 'post:indexentity_post', 4, '', '', 1, 72, '', '2019-09-20 11:34:07'),
(82, 'texte', 19, 'textessimples', 'Texte', '<r2r:ml lang="en">Text</r2r:ml><r2r:ml lang="pt">Texto</r2r:ml><r2r:ml lang="es">Texto</r2r:ml>', '', 'mltext', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;xhtml:block;Lien;Appel de Note', 16, '', 'fckeditor', 'Simple', '', 4, '', '', 1, 73, '', '2013-04-15 15:24:56'),
(83, 'ndla', 4, 'textes', 'Note de l’auteur', '<r2r:ml lang="en">Author\'s note</r2r:ml><r2r:ml lang="pt">Nota do autor</r2r:ml><r2r:ml lang="es">Nota del autor</r2r:ml>', 'ndla,authorsnote', 'text', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;xhtml:block;Lien;Appel de Note', 64, '', 'importable', '', '', 2, '', '', 1, 2, '/tei:TEI/tei:text/tei:front/tei:note[@resp=\'author\']/tei:p', '2018-06-06 12:09:02'),
(98, 'description', 8, 'fichiers', 'Description', '<r2r:ml lang="en">Description</r2r:ml><r2r:ml lang="pt">Descrição</r2r:ml><r2r:ml lang="es">Descripción</r2r:ml>', '', 'text', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;xhtml:block;Lien;Appel de Note', 16, '', 'fckeditor', 'Simple', '', 4, '', '', 32, 2, '', '2013-04-15 16:21:38'),
(99, 'alterfichier', 2, 'textes', 'Texte au format PDF', '<r2r:ml lang="en">PDF version of the document (facsimile)</r2r:ml><r2r:ml lang="pt">Texto em formato PDF</r2r:ml><r2r:ml lang="es">Texto en formato PDF</r2r:ml>', '', 'file', '', '*', '', '', '', 32, '', 'editable', '', '', 0, '', '', 32, 6, '', '2013-04-15 10:48:18'),
(100, 'auteur', 24, 'fichiers', 'Auteur', '<r2r:ml lang="en">Author</r2r:ml><r2r:ml lang="pt">Autor</r2r:ml><r2r:ml lang="es">Autor</r2r:ml>', '', 'persons', '', '', '', '', '', 64, '', 'editable', '', '', 0, '', '', 32, 91, '', '2013-04-15 16:23:52'),
(101, 'auteur', 25, 'liens', 'Auteur de la notice décrivant ce site', '<r2r:ml lang="en">Author of website description</r2r:ml><r2r:ml lang="pt">Autor da ficha do website</r2r:ml><r2r:ml lang="es">Autor de la ficha del sitio web</r2r:ml>', '', 'persons', '', '', '', '', '', 64, '', 'editable', '', '', 0, '', '', 32, 92, '', '2013-04-15 17:20:39'),
(102, 'capturedecran', 6, 'liens', 'Capture d’écran du site', '<r2r:ml lang="en">Website screenshot</r2r:ml><r2r:ml lang="pt">Captação de ecrã do website</r2r:ml><r2r:ml lang="es">Captura de pantalla del sitio web</r2r:ml>', '', 'image', '', '*', '', '', '', 16, '', 'editable', '', '', 0, '', '', 32, 3, '', '2013-04-15 16:53:07'),
(103, 'auteur', 26, 'textessimples', 'Auteur', '<r2r:ml lang="en">Author</r2r:ml><r2r:ml lang="pt">Autor</r2r:ml><r2r:ml lang="es">Autor</r2r:ml>', '', 'persons', '', '', '', '', '', 64, '', 'editable', '', '', 0, '', '', 32, 93, '', '2013-04-15 15:28:34'),
(104, 'langue', 12, 'publications', 'Langue de la publication', '<r2r:ml lang="en">Language of publication</r2r:ml><r2r:ml lang="pt">Língua da publicação</r2r:ml><r2r:ml lang="es">Idioma de la publicación</r2r:ml>', '', 'lang', 'dc.language', '*', '', '', '', 64, '', 'editable', '', '', 0, '', '', 1, 8, '', '2014-04-24 09:51:59'),
(112, 'nom', 28, 'individus', 'Nom', '<r2r:ml lang="en">Surname</r2r:ml><r2r:ml lang="pt">Apelido</r2r:ml><r2r:ml lang="es">Apellido</r2r:ml>', '', 'tinytext', 'dc.title', '*', '', '', '', 16, '', 'editable', '', 'post:indexentity_post', 4, '', '', 1, 1, '', '2019-09-20 11:34:07'),
(113, 'prenom', 28, 'individus', 'Prénom', '<r2r:ml lang="en">Name</r2r:ml><r2r:ml lang="pt">Nome próprio</r2r:ml><r2r:ml lang="es">Nombre</r2r:ml>', '', 'tinytext', '', '*', '', '', '', 16, '', 'editable', '', '', 4, '', '', 1, 2, '', '2013-04-15 15:43:06'),
(116, 'url', 19, 'textessimples', 'Lien', '<r2r:ml lang="en">Link</r2r:ml><r2r:ml lang="pt">Hiperligação</r2r:ml><r2r:ml lang="es">Enlace</r2r:ml>', '', 'url', '', '*', '', '', '', 16, '', 'editable', '', '', 2, '', '', 1, 99, '', '2013-04-15 15:25:11'),
(117, 'date', 19, 'textessimples', 'Date de publication en ligne', '<r2r:ml lang="en">Date of online publication</r2r:ml><r2r:ml lang="pt">Data de publicação online</r2r:ml><r2r:ml lang="es">Fecha de publicación en línea</r2r:ml>', '', 'datetime', '', '*', 'now', '', '', 16, '', 'editable', '', '', 0, '', '', 1, 100, '', '2013-04-15 15:27:29'),
(119, 'email', 30, 'individus', 'Courriel', '<r2r:ml lang="en">Email</r2r:ml><r2r:ml lang="pt">E-mail</r2r:ml><r2r:ml lang="es">Correo</r2r:ml>', '', 'email', '', '*', '', '', '', 16, '', 'editable', '', '', 4, '', '', 1, 3, '', '2013-04-15 16:03:34'),
(120, 'siteweb', 30, 'individus', 'Site web', '<r2r:ml lang="en">Website</r2r:ml><r2r:ml lang="pt">Website</r2r:ml><r2r:ml lang="es">Sitio web</r2r:ml>', '', 'url', '', '*', '', '', '', 16, '', 'editable', '', '', 0, '', '', 1, 4, '', '2013-04-15 16:03:52'),
(121, 'description', 30, 'individus', 'Description', '<r2r:ml lang="en">Full description</r2r:ml><r2r:ml lang="pt">Descrição</r2r:ml><r2r:ml lang="es">Descripción</r2r:ml>', '', 'text', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;xhtml:block;Lien;Appel de Note', 16, '', 'fckeditor', 'Simple', '', 4, '', '', 1, 2, '', '2013-04-15 16:03:23'),
(122, 'accroche', 28, 'individus', 'Accroche', '<r2r:ml lang="en">Brief introduction</r2r:ml><r2r:ml lang="pt">Apresentação sumária</r2r:ml><r2r:ml lang="es">Postítulo</r2r:ml>', '', 'text', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;xhtml:block;Lien;Appel de Note', 16, '', 'fckeditor', 'Simple', '', 4, '', '', 1, 3, '', '2013-04-15 15:46:40'),
(123, 'adresse', 30, 'individus', 'Adresse', '<r2r:ml lang="en">Address</r2r:ml><r2r:ml lang="pt">Endereço</r2r:ml><r2r:ml lang="es">Dirección</r2r:ml>', '', 'text', '', '*', '', '', '', 16, '', 'editable', '3', '', 4, '', '', 1, 102, '', '2013-04-15 16:04:07'),
(124, 'telephone', 30, 'individus', 'Téléphone', '<r2r:ml lang="en">Phone number</r2r:ml><r2r:ml lang="pt">Telefone</r2r:ml><r2r:ml lang="es">Teléfono</r2r:ml>', '', 'tinytext', '', '*', '', '', '', 16, '', 'editable', '', '', 4, '', '', 1, 103, '', '2013-04-15 16:04:25'),
(125, 'photographie', 28, 'individus', 'Photographie', '<r2r:ml lang="en">Illustration</r2r:ml><r2r:ml lang="pt">Imagem</r2r:ml><r2r:ml lang="es">Fotografía</r2r:ml>', '', 'image', '', '*', '', '', '', 16, '', 'editable', '', '', 0, '', '', 1, 104, '', '2013-04-15 16:00:02'),
(127, 'directeurdelapublication', 12, 'publications', 'Directeur de la publication', '<r2r:ml lang="en">Academic editor</r2r:ml><r2r:ml lang="pt">Diretor da publicação</r2r:ml><r2r:ml lang="es">Director de la publicación</r2r:ml>', '', 'persons', '', '', '', '', '', 64, '', 'editable', '', '', 0, '', '', 1, 1, '', '2013-04-11 15:46:25'),
(128, 'legende', 8, 'fichiers', 'Légende', '<r2r:ml lang="en">Caption</r2r:ml><r2r:ml lang="pt">Legenda</r2r:ml><r2r:ml lang="es">Leyenda</r2r:ml>', '', 'text', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;xhtml:block;Lien', 16, '', 'fckeditor', 'Basic', '', 4, '', '', 1, 4, '', '2013-04-15 16:22:41'),
(129, 'credits', 24, 'fichiers', 'Crédits', '<r2r:ml lang="en">Credits</r2r:ml><r2r:ml lang="pt">Créditos</r2r:ml><r2r:ml lang="es">Créditos</r2r:ml>', '', 'tinytext', '', '*', '', '', '', 16, '', 'editable', '', '', 4, '', '', 1, 108, '', '2013-04-15 16:24:05'),
(130, 'editeurscientifique', 14, 'textes', 'Éditeur scientifique', '<r2r:ml lang="en">Academic editor</r2r:ml><r2r:ml lang="pt">Coordenador científico</r2r:ml><r2r:ml lang="es">Editor académico</r2r:ml>', '', 'persons', '', '', '', '', '', 64, '', 'editable', '', '', 0, '', '', 1, 109, '', '2013-04-12 16:47:49'),
(131, 'geographie', 15, 'textes', 'Index géographique', '<r2r:ml lang="en">Geographical index</r2r:ml><r2r:ml lang="pt">Índice geográfico</r2r:ml><r2r:ml lang="es">Índice geográfico</r2r:ml><r2r:ml lang="fr">Index géographique</r2r:ml><r2r:ml lang="de">Geographischer Index</r2r:ml><r2r:ml lang="it">Indice geografico</r2r:ml>', '', 'entries', '', '', '', '', '', 64, '', 'importable', '', '', 0, '', '', 32, 8, '', '2019-07-05 12:14:34'),
(132, 'chrono', 15, 'textes', 'Index chronologique', '<r2r:ml lang="en">Chronological index</r2r:ml><r2r:ml lang="pt">Índice cronológico</r2r:ml><r2r:ml lang="es">Índice cronológico</r2r:ml><r2r:ml lang="fr">Index chronologique</r2r:ml><r2r:ml lang="de">Chronologischer Index</r2r:ml><r2r:ml lang="it">Indice cronologico</r2r:ml>', '', 'entries', '', '', '', '', '', 64, '', 'importable', '', '', 0, '', '', 32, 7, '', '2019-07-05 12:13:16'),
(133, 'theme', 15, 'textes', 'Index thématique', '<r2r:ml lang="en">Subject index</r2r:ml><r2r:ml lang="pt">Índice temático</r2r:ml><r2r:ml lang="es">Índice temático</r2r:ml><r2r:ml lang="fr">Index thématique</r2r:ml><r2r:ml lang="de">Thematischer Index</r2r:ml><r2r:ml lang="it">Indice tematico</r2r:ml>', '', 'entries', '', '', '', '', '', 64, '', 'importable', '', '', 0, '', '', 32, 10, '', '2019-07-05 12:15:33'),
(141, 'vignette', 8, 'fichiers', 'Vignette', '<r2r:ml lang="en">Small image</r2r:ml><r2r:ml lang="pt">Imagem miniatura</r2r:ml><r2r:ml lang="es">Imagen miniatura</r2r:ml>', '', 'image', '', '*', '', '', '', 16, '', 'editable', '', '', 0, '', '', 32, 3, '', '2013-04-15 16:22:19'),
(142, 'alias', 16, 'textes', 'Alias', '<r2r:ml lang="en">Alias</r2r:ml><r2r:ml lang="pt">Alias</r2r:ml><r2r:ml lang="es">Alias</r2r:ml>', '', 'entities', '', '*', '', '', '', 64, '', 'editable', '', '', 0, '', '', 1, 119, '', '2013-04-15 11:25:39'),
(143, 'notefin', 2, 'textes', 'Notes de fin de document', '<r2r:ml lang="en">Endnotes</r2r:ml><r2r:ml lang="pt">Notas de fim de documento</r2r:ml><r2r:ml lang="es">Notas al final del documento</r2r:ml>', 'notefin, endnote,endnote', 'longtext', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;xhtml:block;Lien', 32, '', 'importable', '', '', 4, '', '', 1, 3, '', '2018-06-06 12:09:02'),
(144, 'altertitre', 10, 'publications', 'Titre alternatif de la publication (dans une autre langue)', '<r2r:ml lang="en">Folder translated title (alternative title)</r2r:ml><r2r:ml lang="pt">Título traduzido da publicação</r2r:ml><r2r:ml lang="es">Título traducido de la publicación (título alternativo)</r2r:ml>', '', 'mltext', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;xhtml:block;Appel de Note', 32, '', 'editable', '', '', 4, '', '', 1, 120, '', '2013-04-11 15:36:36'),
(147, 'motscleses', 15, 'textes', 'Palabras claves', '<r2r:ml lang="es">Palabras claves</r2r:ml><r2r:ml lang="de">Palabras claves</r2r:ml><r2r:ml lang="en">Palabras claves</r2r:ml><r2r:ml lang="fr">Palabras claves</r2r:ml><r2r:ml lang="it">Palabras claves</r2r:ml><r2r:ml lang="pt">Palabras claves</r2r:ml>', '', 'entries', '', '', '', '', '', 64, '', 'importable', '', '', 0, '', '', 32, 3, '', '2019-07-05 12:09:10'),
(148, 'motsclesde', 15, 'textes', 'Schlüsselwörter', '<r2r:ml lang="es">Schlüsselwörter</r2r:ml><r2r:ml lang="de">Schlüsselwörter</r2r:ml><r2r:ml lang="en">Schlüsselwörter</r2r:ml><r2r:ml lang="fr">Schlüsselwörter</r2r:ml><r2r:ml lang="it">Schlüsselwörter</r2r:ml><r2r:ml lang="pt">Schlüsselwörter</r2r:ml>', '', 'entries', '', '', '', '', '', 64, '', 'importable', '', '', 0, '', '', 32, 6, '', '2019-07-05 12:12:11'),
(149, 'urlpublicationediteur', 13, 'publications', 'Voir sur le site de l’éditeur', '<r2r:ml lang="en">Publisher\'s website</r2r:ml><r2r:ml lang="pt">Website do editor</r2r:ml><r2r:ml lang="es">Sitio web del editor</r2r:ml>', '', 'url', '', '*', '', '', '', 32, '', 'editable', '', '', 0, '', '', 1, 5, '', '2013-04-11 17:04:50'),
(150, 'nombremaxitems', 6, 'liens', 'Nombre maximum d’items du flux', '<r2r:ml lang="en">Maximum number of feed items</r2r:ml><r2r:ml lang="pt">Número máximo de itens de feed RSS</r2r:ml><r2r:ml lang="es">Cantidad máxima de items del flujo</r2r:ml>', '', 'int', '', '*', '', '', '', 16, '', 'editable', '', '', 0, '', '', 32, 124, '', '2013-04-15 17:06:38'),
(151, 'descriptionouvrage', 31, 'publications', 'Description matérielle', '<r2r:ml lang="pt">Descrição física</r2r:ml><r2r:ml lang="es">Descripción física</r2r:ml>', '', 'text', '', '*', '', '', '', 64, '', 'editable', '', '', 0, '', '', 32, 10, '', '2013-04-11 16:56:11'),
(152, 'site', 0, 'entities_auteurs', 'Site', '<r2r:ml lang="en">Website</r2r:ml><r2r:ml lang="pt">Website</r2r:ml>', 'site, .site', 'url', '', '*', '', '', '', 32, '', 'editable', '', '', 4, '', '', 1, 6, '//tei:ref[@type=\'website\']', '2012-03-21 14:34:25'),
(153, 'auteur', 12, 'publications', 'Auteur', '<r2r:ml lang="en">Author</r2r:ml><r2r:ml lang="pt">Autor</r2r:ml><r2r:ml lang="es">Autor</r2r:ml>', '', 'persons', '', '', '', '', '', 64, '', 'editable', '', '', 0, '', '', 1, 2, '', '2013-04-11 15:51:14'),
(154, 'traducteur', 12, 'publications', 'Traducteur', '<r2r:ml lang="en">Translator</r2r:ml><r2r:ml lang="pt">Tradutor</r2r:ml><r2r:ml lang="es">Traductor</r2r:ml>', '', 'persons', '', '', '', '', '', 64, '', 'editable', '', '', 0, '', '', 1, 3, '', '2013-04-11 16:16:00'),
(155, 'editeurscientifique', 12, 'publications', 'Éditeur scientifique', '<r2r:ml lang="pt">Coordenador científico</r2r:ml><r2r:ml lang="es">Editor científico</r2r:ml>', '', 'persons', '', '', '', '', '', 64, '', 'editable', '', '', 0, '', '', 1, 4, '', '2013-04-11 16:16:34'),
(156, 'issn', 12, 'publications', 'ISSN edition papier (pour les collections)', '<r2r:ml lang="es">ISSN edición papel (para las colecciones)</r2r:ml>', '', 'tinytext', '', '*', '', '', '', 64, '', 'editable', '', 'pre:check_issn', 0, '', '', 1, 12, '', '2014-06-23 10:47:27'),
(158, 'lieuedition', 31, 'publications', 'Lieu d’édition', '<r2r:ml lang="pt">Lugar da edição</r2r:ml><r2r:ml lang="es">Lugar de edición</r2r:ml>', '', 'tinytext', '', '*', '', '', '', 64, '', 'editable', '', '', 0, '', '', 1, 2, '', '2013-04-11 16:49:13'),
(159, 'anneeedition', 31, 'publications', 'Année d’édition', '<r2r:ml lang="pt">Ano da edição</r2r:ml><r2r:ml lang="es">Año de edición</r2r:ml>', '', 'tinytext', '', '*', '', '', '', 64, '', 'editable', '', '', 0, '', 'a:3:{s:4:\\"user\\";s:6:\\"%1111%\\";s:5:\\"lodel\\";s:10:\\"/^[0-9]+$/\\";s:5:\\"model\\";s:11:\\"traditional\\";}', 1, 3, '', '2013-04-11 16:49:28'),
(160, 'nombrepages', 31, 'publications', 'Nombre de pages', '<r2r:ml lang="pt">Número de páginas</r2r:ml><r2r:ml lang="es">Número de páginas</r2r:ml>', '', 'tinytext', '', '*', '', '', '', 64, '', 'editable', '', '', 0, '', '', 1, 7, '', '2013-04-11 16:55:11'),
(161, 'formatlivre', 31, 'publications', 'Format', '<r2r:ml lang="es">Formato </r2r:ml>', '', 'tinytext', '', '*', '', '', '', 64, '', 'editable', '', '', 0, '', '', 1, 9, '', '2013-04-11 16:55:36'),
(162, 'prix', 31, 'publications', 'Prix du volume papier', '<r2r:ml lang="pt">Preço</r2r:ml><r2r:ml lang="es">Precio</r2r:ml>', '', 'tinytext', '', '*', '', '', '', 64, '', 'editable', '', '', 0, '', '', 1, 11, '', '2013-04-11 16:56:32'),
(163, 'liencommercial', 13, 'publications', 'Commander / acheter', '<r2r:ml lang="pt">Encomendar / Comprar</r2r:ml><r2r:ml lang="es">Encargar / Comprar</r2r:ml>', '', 'url', '', '*', '', '', '', 32, '', 'editable', '', '', 0, '', '', 1, 7, '', '2013-04-11 17:05:15'),
(164, 'motsclesfr', 32, 'publications', 'Mots-clés', '<r2r:ml lang="es">Mots-clés</r2r:ml><r2r:ml lang="de">Mots-clés</r2r:ml><r2r:ml lang="en">Mots-clés</r2r:ml><r2r:ml lang="fr">Mots-clés</r2r:ml><r2r:ml lang="it">Mots-clés</r2r:ml><r2r:ml lang="pt">Mots-clés</r2r:ml>', '', 'entries', '', '', '', '', '', 64, '', 'editable', '', '', 0, '', '', 32, 1, '', '2019-07-04 16:32:12'),
(165, 'theme', 32, 'publications', 'Index thématique', '<r2r:ml lang="es">Índice temático</r2r:ml><r2r:ml lang="de">Thematischer Index</r2r:ml><r2r:ml lang="en">Subject index</r2r:ml><r2r:ml lang="fr">Index thématique</r2r:ml><r2r:ml lang="pt">Índice temático</r2r:ml><r2r:ml lang="it">Indice tematico</r2r:ml>', '', 'entries', '', '', '', '', '', 64, '', 'editable', '', '', 0, '', '', 32, 10, '', '2019-07-04 16:54:37'),
(166, 'geographie', 32, 'publications', 'Index géographique', '<r2r:ml lang="es">Índice geográfico</r2r:ml><r2r:ml lang="de">Geographischer Index</r2r:ml><r2r:ml lang="en">Geographical index</r2r:ml><r2r:ml lang="fr">Index géographique</r2r:ml><r2r:ml lang="it">Indice geografico</r2r:ml><r2r:ml lang="pt">Índice geográfico</r2r:ml>', '', 'entries', '', '', '', '', '', 64, '', 'editable', '', '', 0, '', '', 32, 9, '', '2019-07-04 16:52:58'),
(183, 'racinemets', 11, 'publications', 'Racine METS', '<r2r:ml lang="pt">Raiz METS</r2r:ml><r2r:ml lang="es">Raíz METS</r2r:ml>', '', 'boolean', '', '*', '', '', '', 64, '', 'editable', '', '', 0, '', '', 32, 130, '', '2013-04-11 17:31:19'),
(186, 'titre', 34, 'fichiersexternes', 'Titre', '<r2r:ml lang="en">Title</r2r:ml><r2r:ml lang="pt">Título</r2r:ml><r2r:ml lang="es">Título</r2r:ml>', '', 'tinytext', 'dc.title', '*', '', '', 'xhtml:fontstyle;xhtml:phrase', 64, '', 'editable', '', 'post:indexentity_post', 0, '', '', 1, 133, '', '2019-09-20 11:34:07'),
(187, 'object', 35, 'fichiersexternes', 'Objet', '<r2r:ml lang="pt">Objecto</r2r:ml><r2r:ml lang="en">Object</r2r:ml><r2r:ml lang="es">Objeto</r2r:ml>', '', 'text', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;xhtml:block;Lien', 64, '', 'editable', '5', '', 0, '', '', 32, 134, '', '2013-04-15 17:27:06'),
(188, 'description', 35, 'fichiersexternes', 'Description', '<r2r:ml lang="pt">Descrição</r2r:ml><r2r:ml lang="en">Description</r2r:ml><r2r:ml lang="es">Descripción</r2r:ml>', '', 'text', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;xhtml:block;Lien', 64, '', 'fckeditor', '', '', 0, '', '', 32, 135, '', '2013-04-15 17:27:20'),
(189, 'vignette', 35, 'fichiersexternes', 'Vignette', '<r2r:ml lang="en">Small image</r2r:ml><r2r:ml lang="pt">Imagem miniatura</r2r:ml><r2r:ml lang="es">Imagen miniatura</r2r:ml>', '', 'image', '', '*', '', '', '', 64, '', 'editable', '', '', 0, '', '', 32, 136, '', '2013-04-15 17:27:36'),
(190, 'legende', 35, 'fichiersexternes', 'Légende', '<r2r:ml lang="en">Caption</r2r:ml><r2r:ml lang="pt">Legenda</r2r:ml><r2r:ml lang="es">Leyenda</r2r:ml>', '', 'text', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;xhtml:block;Lien', 64, '', 'fckeditor', '', '', 0, '', '', 32, 137, '', '2013-04-15 17:28:15'),
(191, 'datepubli', 35, 'fichiersexternes', 'Date de publication', '<r2r:ml lang="en">Published online since</r2r:ml><r2r:ml lang="pt">Data de publicação</r2r:ml><r2r:ml lang="es">Fecha de publicación</r2r:ml>', '', 'date', '', '*', 'today', '', '', 64, '', 'editable', '', '', 0, '', '', 32, 138, '', '2013-04-15 17:28:46'),
(192, 'urlaccesmedia', 35, 'fichiersexternes', 'Permalien', '<r2r:ml lang="en">Permalink</r2r:ml><r2r:ml lang="pt">Ligação permanente</r2r:ml><r2r:ml lang="es">Enlace permanente</r2r:ml>', '', 'url', '', '*', '', '', '', 64, '', 'editable', '', '', 0, '', '', 32, 139, '', '2013-04-15 17:29:33'),
(193, 'urlmedia', 35, 'fichiersexternes', 'url du média', '<r2r:ml lang="en">Media URL</r2r:ml><r2r:ml lang="pt">Url do media</r2r:ml><r2r:ml lang="es">URL del medio</r2r:ml>', '', 'url', '', '*', '', '', '', 64, '', 'editable', '', '', 0, '', '', 32, 140, '', '2013-04-15 17:29:59'),
(194, 'auteur', 36, 'fichiersexternes', 'Auteur', '<r2r:ml lang="en">Author</r2r:ml><r2r:ml lang="pt">Autor</r2r:ml><r2r:ml lang="es">Autor</r2r:ml>', '', 'persons', '', '', '', '', '', 64, '', 'editable', '', '', 0, '', '', 32, 141, '', '2013-04-15 17:30:40'),
(195, 'credits', 36, 'fichiersexternes', 'Crédits', '<r2r:ml lang="en">Credits</r2r:ml><r2r:ml lang="pt">Créditos</r2r:ml><r2r:ml lang="es">Créditos</r2r:ml>', '', 'tinytext', '', '*', '', '', '', 64, '', 'editable', '', '', 0, '', '', 32, 142, '', '2013-04-15 17:30:56'),
(197, 'datepubli', 8, 'fichiers', 'Date de publication', '<r2r:ml lang="en">Published online since</r2r:ml><r2r:ml lang="pt">Data de publicação</r2r:ml><r2r:ml lang="es">Fecha de publicación</r2r:ml>', '', 'date', '', '*', 'today', '', '', 64, '', 'editable', '', '', 0, '', '', 32, 144, '', '2013-04-15 16:22:57'),
(201, 'altertitre', 18, 'textessimples', 'Titre alternatif', '<r2r:ml lang="en">Translated title (alternative title)</r2r:ml><r2r:ml lang="pt">Título traduzido do documento</r2r:ml><r2r:ml lang="es">Título traducido del documento </r2r:ml>', '', 'mltext', '', '*', '', '', '', 16, '', 'editable', '', '', 0, '', '', 32, 147, '', '2013-04-15 15:24:25'),
(202, 'altertitre', 5, 'liens', 'Titre alternatif (dans une autre langue)', '<r2r:ml lang="en">Translated title (alternative title)</r2r:ml><r2r:ml lang="pt">Título traduzido</r2r:ml><r2r:ml lang="es">Título traducido (título alternativo)</r2r:ml>', '', 'mltext', '', '*', '', '', '', 16, '', 'editable', '', '', 0, '', '', 32, 148, '', '2013-04-15 16:44:19'),
(203, 'traduction', 16, 'textes', 'Ce document est une traduction de :', '<r2r:ml lang="en">The document is a translation of:</r2r:ml><r2r:ml lang="pt">Este documento foi traduzido por:</r2r:ml><r2r:ml lang="es">Este documento es una traducción de:</r2r:ml>', '', 'entities', '', '*', '', '', '', 16, '', 'editable', '', '', 0, '', '', 32, 149, '', '2013-04-15 11:27:50'),
(204, 'imagehabillee', 16, 'textes', 'Habillage des images', '<r2r:ml lang="en">Image display: runaround mode</r2r:ml><r2r:ml lang="pt">Moldagem de texto junto às imagens</r2r:ml><r2r:ml lang="es">Ajuste de las imágenes</r2r:ml>', '', 'boolean', '', '*', '', '', '', 16, '', 'editable', '', '', 0, '', '', 32, 150, '', '2013-04-15 11:36:49'),
(207, 'fichierreference', 2, 'textes', 'Fichier de référence', '<r2r:ml lang="pt">Ficheiro de referência</r2r:ml><r2r:ml lang="es">Archivo de referencia</r2r:ml>', '', 'boolean', '', '*', '', '', '', 16, '', 'editable', '', '', 0, '', '', 32, 7, '', '2013-04-15 10:48:39'),
(210, 'prixcommercialisationnumero', 43, 'publications', 'Prix de commercialisation du numéro', '<r2r:ml lang="pt">Preço de comercialização do número</r2r:ml><r2r:ml lang="en">Price</r2r:ml><r2r:ml lang="es">Precio de comercialización del número</r2r:ml>', '', 'text', '', '*', '', '', '', 16, '', 'editable', '', '', 0, '', '', 32, 2, '', '2013-04-11 17:35:30'),
(235, 'motsclesen', 32, 'publications', 'Keywords', '<r2r:ml lang="es">Keywords</r2r:ml><r2r:ml lang="de">Keywords</r2r:ml><r2r:ml lang="en">Keywords</r2r:ml><r2r:ml lang="fr">Keywords</r2r:ml><r2r:ml lang="it">Keywords</r2r:ml><r2r:ml lang="pt">Keywords</r2r:ml>', '', 'entries', '', '', '', '', '', 64, '', 'editable', '', '', 0, '', '', 32, 2, '', '2019-07-04 16:34:18'),
(236, 'motsclesde', 32, 'publications', 'Schlüsselwörter', '<r2r:ml lang="es">Schlüsselwörter</r2r:ml><r2r:ml lang="en">Schlüsselwörter</r2r:ml><r2r:ml lang="de">Schlüsselwörter</r2r:ml><r2r:ml lang="fr">Schlüsselwörter</r2r:ml><r2r:ml lang="it">Schlüsselwörter</r2r:ml><r2r:ml lang="pt">Schlüsselwörter</r2r:ml>', '', 'entries', '', '', '', '', '', 64, '', 'editable', '', '', 0, '', '', 32, 6, '', '2019-07-04 16:46:21'),
(237, 'motscleses', 32, 'publications', 'Palabras claves', '<r2r:ml lang="es">Palabras claves</r2r:ml><r2r:ml lang="de">Palabras claves</r2r:ml><r2r:ml lang="en">Palabras claves</r2r:ml><r2r:ml lang="fr">Palabras claves</r2r:ml><r2r:ml lang="it">Palabras claves</r2r:ml><r2r:ml lang="pt">Palabras claves</r2r:ml>', '', 'entries', '', '', '', '', '', 64, '', 'editable', '', '', 0, '', '', 32, 3, '', '2019-07-04 16:35:39'),
(238, 'datemisenligne', 41, 'textes', 'Date de mise en ligne', '<r2r:ml lang="pt">Data de colocação online</r2r:ml><r2r:ml lang="en">Published online since</r2r:ml><r2r:ml lang="es">Fecha de publicación en línea</r2r:ml>', '', 'date', '', 'permanent', '', '', '', 16, '', 'display', '', 'updatedatepubli', 0, '', '', 1, 1, '', '2019-09-20 11:34:07'),
(239, 'dateacceslibre', 41, 'textes', 'Date de mise en accès libre', '<r2r:ml lang="pt">Data de publicação em acesso livre</r2r:ml><r2r:ml lang="en">Available in open access since</r2r:ml><r2r:ml lang="es">Fecha de publicación en acceso libre</r2r:ml>', '', 'date', '', '*', '', '', '', 16, '', 'editable', '', '', 0, '', '', 32, 2, '', '2013-04-15 11:42:52'),
(240, 'datemisenligne', 42, 'publications', 'Date de mise en ligne', '<r2r:ml lang="pt">Data de colocação online</r2r:ml><r2r:ml lang="en">Published online since</r2r:ml><r2r:ml lang="es">Fecha de publicación</r2r:ml>', '', 'date', '', 'permanent', '', '', '', 16, '', 'display', '', 'updatedatepubli', 0, '', '', 1, 1, '', '2019-09-20 11:34:07'),
(241, 'dateacceslibre', 42, 'publications', 'Date de mise en accès libre', '<r2r:ml lang="pt">Data de publicação em acesso livre</r2r:ml><r2r:ml lang="en">Available in open access since</r2r:ml><r2r:ml lang="es">Fecha de publicación en acceso libre</r2r:ml>', '', 'date', '', '*', '', '', '', 16, '', 'editable', '', '', 0, '', '', 32, 2, '', '2013-04-11 17:37:03'),
(242, 'datemisenligne', 44, 'fichiers', 'Date de mise en ligne', '<r2r:ml lang="pt">Data de colocação online</r2r:ml><r2r:ml lang="en">Published online since</r2r:ml><r2r:ml lang="es">Fecha de publicación en línea</r2r:ml>', '', 'date', '', 'permanent', '', '', '', 16, '', 'display', '', 'updatedatepubli', 0, '', '', 1, 1, '', '2019-09-20 11:34:07'),
(243, 'dateacceslibre', 44, 'fichiers', 'Date de mise en accès libre', '<r2r:ml lang="pt">Data de publicação em acesso livre</r2r:ml><r2r:ml lang="en">Available in open access since</r2r:ml><r2r:ml lang="es">Fecha de publicación en acceso libre</r2r:ml>', '', 'date', '', '*', '', '', '', 16, '', 'editable', '', '', 0, '', '', 32, 2, '', '2013-04-15 16:24:58'),
(244, 'datemisenligne', 45, 'liens', 'Date de mise en ligne', '<r2r:ml lang="pt">Data de colocação online</r2r:ml><r2r:ml lang="en">Published online since</r2r:ml><r2r:ml lang="es">Fecha de publicación en línea</r2r:ml>', '', 'date', '', 'permanent', '', '', '', 16, '', 'display', '', 'updatedatepubli', 0, '', '', 1, 1, '', '2019-09-20 11:34:07'),
(245, 'dateacceslibre', 45, 'liens', 'Date de mise en accès libre', '<r2r:ml lang="pt">Data de publicação em acesso livre</r2r:ml><r2r:ml lang="en">Available in open access since</r2r:ml><r2r:ml lang="es">Fecha de publicación en acceso libre</r2r:ml>', '', 'date', '', '*', '', '', '', 16, '', 'editable', '', '', 0, '', '', 32, 2, '', '2013-04-15 17:21:32'),
(246, 'datemisenligne', 46, 'textessimples', 'Date de mise en ligne', '<r2r:ml lang="pt">Data de colocação online</r2r:ml><r2r:ml lang="en">Published online since</r2r:ml><r2r:ml lang="es">Fecha de publicación en línea</r2r:ml>', '', 'date', '', 'permanent', '', '', '', 16, '', 'display', '', 'updatedatepubli', 0, '', '', 1, 1, '', '2019-09-20 11:34:07'),
(247, 'dateacceslibre', 46, 'textessimples', 'Date de mise en accès libre', '<r2r:ml lang="pt">Data de publicação em acesso livre</r2r:ml><r2r:ml lang="en">Available in open access since</r2r:ml><r2r:ml lang="es">Fecha de publicación en acceso libre</r2r:ml>', '', 'date', '', '*', '', '', '', 16, '', 'editable', '', '', 0, '', '', 32, 2, '', '2013-04-15 15:29:41'),
(248, 'datemisenligne', 47, 'individus', 'Date de mise en ligne', '<r2r:ml lang="pt">Data de colocação online</r2r:ml><r2r:ml lang="en">Published online since</r2r:ml><r2r:ml lang="es">Fecha de publicación en línea</r2r:ml>', '', 'date', '', 'permanent', '', '', '', 16, '', 'display', '', 'updatedatepubli', 0, '', '', 1, 1, '', '2019-09-20 11:34:07'),
(249, 'dateacceslibre', 47, 'individus', 'Date de mise en accès libre', '<r2r:ml lang="pt">Data de publicação em acesso livre</r2r:ml><r2r:ml lang="en">Available in open access since</r2r:ml><r2r:ml lang="es">Fecha de publicación en acceso libre</r2r:ml>', '', 'date', '', '*', '', '', '', 16, '', 'editable', '', '', 0, '', '', 32, 2, '', '2013-04-15 16:12:57'),
(250, 'datemisenligne', 48, 'fichiersexternes', 'Date de mise en ligne', '<r2r:ml lang="pt">Data de colocação online</r2r:ml><r2r:ml lang="en">Published online since</r2r:ml><r2r:ml lang="es">Fecha de publicación en línea</r2r:ml>', '', 'date', '', 'permanent', '', '', '', 16, '', 'display', '', 'updatedatepubli', 0, '', '', 1, 1, '', '2019-09-20 11:34:07'),
(251, 'dateacceslibre', 48, 'fichiersexternes', 'Date de mise en accès libre', '<r2r:ml lang="pt">Data de publicação em acesso livre</r2r:ml><r2r:ml lang="en">Available in open access since</r2r:ml><r2r:ml lang="es">Fecha de publicación en acceso libre</r2r:ml>', '', 'date', '', '*', '', '', '', 16, '', 'editable', '', '', 0, '', '', 32, 2, '', '2013-04-15 17:32:46'),
(257, 'vignette', 6, 'liens', 'Vignette', '<r2r:ml lang="en">Small image</r2r:ml><r2r:ml lang="pt">vinheta</r2r:ml><r2r:ml lang="es">Imagen miniatura</r2r:ml>', '', 'image', '', '*', '', '', '', 64, '', 'editable', '', '', 0, '', '', 1, 158, '', '2013-04-15 17:15:16'),
(258, 'vignettesimple', 16, 'textes', 'Vignettisation simple', '<r2r:ml lang="en">Simple thumbnail</r2r:ml><r2r:ml lang="pt">vinheta simples</r2r:ml><r2r:ml lang="es">Viñetas simples</r2r:ml>', '', 'boolean', '', '*', '', '', '', 64, '', 'editable', '', '', 0, '', '', 1, 159, '', '2013-04-15 11:39:05'),
(259, 'langueoriginale', 12, 'publications', 'Langue originale', '<r2r:ml lang="es">Idioma original</r2r:ml>', '', 'lang', '', '*', '', '', '', 64, '', 'editable', '', '', 0, '', '', 1, 10, '', '2013-04-11 16:21:03'),
(261, 'coediteur', 31, 'publications', 'Co-éditeur', '<r2r:ml lang="es">Co-editor</r2r:ml>', '', 'entries', '', '', '', '', '', 64, '', 'editable', '', '', 0, '', '', 32, 1, '', '2013-04-11 16:40:06'),
(262, 'ocr', 11, 'publications', 'Publication issue d’une numérisation OCR', '<r2r:ml lang="en">The document is a transcript from an OCR</r2r:ml><r2r:ml lang="pt">Documento obtido por digitalização OCR</r2r:ml><r2r:ml lang="es">Documento obtenido de una digitalización OCR</r2r:ml>', '', 'boolean', '', '*', '', '', '', 64, '', 'editable', '', '', 0, '', '', 1, 161, '', '2013-04-11 17:32:39'),
(265, 'langueoriginale', 3, 'textes', 'Langue originale', '<r2r:ml lang="es">Idioma original</r2r:ml>', '', 'lang', '', '*', '', '', '', 64, '', 'editable', '', '', 0, '', '', 1, 4, '', '2013-04-12 17:22:22'),
(266, 'fichierwordnumerise', 16, 'textes', 'Fichier Word numérisé', '<r2r:ml lang="es">Archivo Word digital</r2r:ml>', '', 'file', '', '*', '', '', '', 64, '', 'editable', '', '', 0, '', '', 1, 163, '', '2013-04-15 11:39:45'),
(268, 'languesecondaire', 12, 'publications', 'Langue secondaire', '<r2r:ml lang="es">Idioma secundario</r2r:ml>', '', 'lang', '', '*', '', '', '', 64, '', 'editable', '', '', 0, '', '', 1, 9, '', '2013-04-11 16:20:44'),
(272, 'issnelectronique', 12, 'publications', 'ISSN édition électronique (pour les collections)', '<r2r:ml lang="es">ISSN edición electrónica (para las colecciones)</r2r:ml>', '', 'tinytext', '', '*', '', '', '', 64, '', 'editable', '', 'pre:check_issn', 0, '', '', 1, 13, '', '2014-06-23 10:47:27'),
(273, 'resume', 13, 'publications', 'Résumé', '<r2r:ml lang="en">Abstract</r2r:ml><r2r:ml lang="pt">Resumo</r2r:ml><r2r:ml lang="es">Resumen</r2r:ml>', '', 'mltext', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;xhtml:block;Lien;Appel de Note', 16, '', 'fckeditor', 'Simple,550,400', '', 8, '', '', 32, 4, '', '2013-04-11 17:04:06'),
(277, 'isbnhtml', 31, 'publications', 'ISBN HTML', '<r2r:ml lang="en">HTML ISBN</r2r:ml><r2r:ml lang="es">ISBN HTML </r2r:ml>', '', 'tinytext', '', '*', '', '', '', 16, '', 'editable', '', 'pre:check_isbn', 0, '', '', 1, 5, '', '2013-04-11 16:50:23'),
(279, 'personnecitee', 32, 'publications', 'Personnes citées', '<r2r:ml lang="es">Personas citadas</r2r:ml><r2r:ml lang="en">Persons mentioned</r2r:ml><r2r:ml lang="de">Benannte Personen</r2r:ml><r2r:ml lang="fr">Personnes citées</r2r:ml><r2r:ml lang="it">Persone citate</r2r:ml><r2r:ml lang="pt">Pessoas citadas</r2r:ml>', '', 'persons', '', '', '', '', '', 64, '', 'editable', '', '', 0, '', '', 32, 12, '', '2019-07-04 16:58:09'),
(282, 'titre', 50, 'modulesaffichage', 'Titre', '<r2r:ml lang="es">Título</r2r:ml>', '', 'text', 'dc.title', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special', 32, '', 'editable', '', '', 0, '', '', 1, 174, '', '2013-04-15 17:42:44'),
(283, 'altertitre', 50, 'modulesaffichage', 'Titre traduit', '<r2r:ml lang="es">Título traducido</r2r:ml>', '', 'mltext', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special', 32, '', 'editable', '', '', 0, '', '', 1, 175, '', '2013-04-15 17:43:06'),
(284, 'affichage', 50, 'modulesaffichage', 'Type d\'affichage', '<r2r:ml lang="es">Tipo de visualización</r2r:ml>', '', 'list', '', '*', '1 element', '', '', 32, '', 'editable', '1 element, 3 elements, 6 elements, hidden', '', 0, '', '', 1, 176, '', '2013-04-15 17:43:31'),
(285, 'idcontainer', 50, 'modulesaffichage', 'ID du parent ou de l\'entrée d\'index', '<r2r:ml lang="es">ID del nombre o de la entrada del índice</r2r:ml>', '', 'number', '', '*', '', '', '', 32, '', 'editable', '', '', 0, '', '', 1, 177, '', '2013-04-16 11:02:30'),
(286, 'nbelementsmax', 50, 'modulesaffichage', 'Nombre d\'éléments maximum affiché dans le module', '<r2r:ml lang="es">Cantidad máxima de elementos visualizada en el módulo</r2r:ml>', '', 'number', '', '*', '10', '', '', 32, '', 'editable', '', '', 0, '', '', 1, 178, '', '2013-04-16 11:04:02'),
(287, 'politiqueacces', 50, 'modulesaffichage', 'Politique d\'accès', '<r2r:ml lang="es">Política de acceso</r2r:ml>', '', 'list', '', '*', 'all', '', '', 32, '', 'editable', 'all, open access, restricted access', '', 0, '', '', 1, 179, '', '2013-04-16 11:04:18'),
(288, 'ordre', 50, 'modulesaffichage', 'Ordre d\'affichage', '<r2r:ml lang="es">Orden de la visualización</r2r:ml>', '', 'list', '', '*', 'rank', '', '', 32, '', 'editable', 'rank,first publication date,electronic publication date', '', 0, '', '', 1, 180, '', '2013-04-16 11:04:58'),
(289, 'mlnom', 0, 'indexes', 'Nom dans un autre langue', '', '', 'mltext', '', '*', '', '', '', 16, '', 'editable', '', '', 4, '', '', 1, 181, '', '2012-11-14 10:34:39'),
(290, 'dossiers', 32, 'publications', 'Dossiers', '<r2r:ml lang="es">Selecciones</r2r:ml><r2r:ml lang="en">Selections</r2r:ml><r2r:ml lang="de">Selektionen</r2r:ml><r2r:ml lang="fr">Dossiers</r2r:ml><r2r:ml lang="it">Selezioni</r2r:ml><r2r:ml lang="pt">Dossiês</r2r:ml>', '', 'entries', '', '', '', '', '', 64, '', 'editable', '', '', 0, '', '', 32, 7, '', '2019-07-04 16:48:20'),
(295, 'revuedepresse', 13, 'publications', 'Revues de presse', '<r2r:ml lang="es">Revistas de prensa</r2r:ml>', '', 'entities', '', '*', '', '', '', 32, '', 'editable', '', '', 0, '', '', 1, 187, '', '2013-04-11 17:05:46'),
(296, 'prioritaire', 0, 'indexes', 'Prioritaire', '', '', 'boolean', '', '*', '', '', '', 32, '', 'editable', '', '', 0, '', '', 1, 188, '', '2012-11-27 17:43:36'),
(297, 'fondcouvertureauto', 11, 'publications', 'Image de fond de couverture automatique', '<r2r:ml lang="es">Imagen de fondo de portada automática</r2r:ml>', '', 'image', '', '*', '', '', '', 32, '', 'editable', '', '', 0, '', '', 1, 189, '', '2019-09-20 11:34:07'),
(298, 'remerciements', 4, 'textes', 'Remerciements', '', 'remerciements,acknowledgments,acknowledgements', 'text', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;xhtml:block;Lien;Appel de Note;style:strict', 64, '', 'importable', '', '', 2, '', '', 1, 190, '/tei:TEI/tei:text/tei:front/tei:div[@type=\'ack\']/tei:p', '2013-07-30 15:43:30'),
(302, 'extrait', 13, 'publications', 'Extrait (utilisé  en l\'absence de résumé)', '<r2r:ml lang="en">Excerpt (when no abstract available)</r2r:ml><r2r:ml lang="es">Usado (si no se encuentra ningún resumen)</r2r:ml>', '', 'text', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;xhtml:block;Lien', 64, '', 'wysiwyg_ckeditor', '', '', 0, '', '', 1, 192, '', '2014-10-01 17:12:39'),
(307, 'motsclespt', 32, 'publications', 'Palavras chaves', '<r2r:ml lang="es">Palavras chaves</r2r:ml><r2r:ml lang="de">Palavras chaves</r2r:ml><r2r:ml lang="en">Palavras chaves</r2r:ml><r2r:ml lang="fr">Palavras chaves</r2r:ml><r2r:ml lang="it">Palavras chaves</r2r:ml><r2r:ml lang="pt">Palavras chaves</r2r:ml>', '', 'entries', '', '', '', '', '', 64, '', 'editable', '', '', 0, '', '', 32, 4, '', '2019-07-04 16:42:47'),
(312, 'motsclesit', 32, 'publications', 'Parole chiave', '<r2r:ml lang="es">Parole chiave</r2r:ml><r2r:ml lang="de">Parole chiave</r2r:ml><r2r:ml lang="en">Parole chiave</r2r:ml><r2r:ml lang="fr">Parole chiave</r2r:ml><r2r:ml lang="it">Parole chiave</r2r:ml><r2r:ml lang="pt">Parole chiave</r2r:ml>', '', 'entries', '', '', '', '', '', 64, '', 'editable', '', '', 0, '', '', 32, 5, '', '2019-07-04 16:44:12'),
(316, 'chrono', 32, 'publications', 'Index chronologique', '<r2r:ml lang="es">Índice cronológico</r2r:ml><r2r:ml lang="en">Chronological index</r2r:ml><r2r:ml lang="de">Chronologischer Index</r2r:ml><r2r:ml lang="fr">Index chronologique</r2r:ml><r2r:ml lang="it">Indice cronologico</r2r:ml><r2r:ml lang="pt">Índice cronológico</r2r:ml>', '', 'entries', '', '', '', '', '', 64, '', 'editable', '', '', 0, '', '', 32, 8, '', '2019-07-04 16:50:47'),
(322, 'motsclespt', 15, 'textes', 'Palavras chaves', '<r2r:ml lang="es">Palavras chaves</r2r:ml><r2r:ml lang="de">Palavras chaves</r2r:ml><r2r:ml lang="en">Palavras chaves</r2r:ml><r2r:ml lang="fr">Palavras chaves</r2r:ml><r2r:ml lang="it">Palavras chaves</r2r:ml><r2r:ml lang="pt">Palavras chaves</r2r:ml>', '', 'entries', '', '', '', '', '', 64, '', 'importable', '', '', 0, '', '', 32, 4, '', '2019-07-05 12:10:22'),
(328, 'motsclesit', 15, 'textes', 'Parole chiave', '<r2r:ml lang="es">Parole chiave</r2r:ml><r2r:ml lang="de">Parole chiave</r2r:ml><r2r:ml lang="en">Parole chiave</r2r:ml><r2r:ml lang="fr">Parole chiave</r2r:ml><r2r:ml lang="it">Parole chiave</r2r:ml><r2r:ml lang="pt">Parole chiave</r2r:ml>', '', 'entries', '', '', '', '', '', 64, '', 'importable', '', '', 0, '', '', 32, 5, '', '2019-07-05 12:11:11'),
(334, 'fundername', 0, 'funder', 'Funder name', '<r2r:ml lang="fr">Nom de l’organisme de financement</r2r:ml><r2r:ml lang="es">Nombre de la entidad financiadora</r2r:ml><r2r:ml lang="it">Nome dell’organismo di finanziamento</r2r:ml><r2r:ml lang="de">Name des Geldgebers</r2r:ml>', '', 'text', 'screen name', '*', '', '', '', 32, '', 'editable', '', '', 0, '', '', 32, 193, '', '2019-07-05 12:24:40'),
(337, 'funderid', 0, 'funder', 'Funder ID', '<r2r:ml lang="fr">ID de l’organisme de financement</r2r:ml><r2r:ml lang="es">ID de la entidad financiadora</r2r:ml><r2r:ml lang="it">ID dell’organismo di finanziamento</r2r:ml><r2r:ml lang="de">ID des Geldgebers</r2r:ml>', '', 'tinytext', 'index key', '*', '', '', '', 32, '', 'editable', '', '', 0, '', '', 32, 194, '', '2019-07-05 12:24:40'),
(340, 'grantnumber', 0, 'entities_funder', 'Grant Number', '<r2r:ml lang="fr">Référence du projet</r2r:ml><r2r:ml lang="es">Referencia del proyecto</r2r:ml><r2r:ml lang="it">Grant number</r2r:ml><r2r:ml lang="de">Grant-Nummer</r2r:ml>', '', 'text', '', '*', '', '', '', 32, '', 'editable', '', '', 0, '', '', 32, 195, '', '2019-07-05 12:24:40'),
(343, 'funder', 12, 'publications', 'Funder', '<r2r:ml lang="fr">Financement</r2r:ml><r2r:ml lang="es">Financiación</r2r:ml><r2r:ml lang="it">Finanziamento</r2r:ml><r2r:ml lang="de">Finanzierung</r2r:ml>', '', 'entries', '', '', '', '', '', 64, '', 'editable', '', '', 0, '', '', 32, 196, '', '2019-07-05 12:24:40');

#
# Dumping data for table 'tablefieldgroups'
#

INSERT INTO #_TP_tablefieldgroups (id, name, class, title, altertitle, comment, status, rank, upd) VALUES (1, 'grtitre', 'textes', 'Titres', '<r2r:ml lang="en">Titles</r2r:ml><r2r:ml lang="pt">Títulos</r2r:ml><r2r:ml lang="es">Títulos</r2r:ml>', '', 1, 1, '2013-04-12 16:39:43'),
(2, 'grtexte', 'textes', 'Texte', '<r2r:ml lang="en">Text</r2r:ml><r2r:ml lang="pt">Texto</r2r:ml><r2r:ml lang="es">Texto</r2r:ml>', '', 1, 9, '2013-04-15 10:39:15'),
(3, 'grmeta', 'textes', 'Métadonnées', '<r2r:ml lang="en">Metadata</r2r:ml><r2r:ml lang="pt">Metadados</r2r:ml><r2r:ml lang="es">Metadatos</r2r:ml>', '', 1, 4, '2013-04-12 16:49:16'),
(4, 'graddenda', 'textes', 'Addenda', '<r2r:ml lang="pt">Adenda</r2r:ml><r2r:ml lang="en">Addenda</r2r:ml><r2r:ml lang="es">Addenda</r2r:ml>', '', 1, 6, '2013-04-12 17:30:10'),
(5, 'grtitre', 'liens', 'Titre', '<r2r:ml lang="en">Title</r2r:ml><r2r:ml lang="pt">Títulos</r2r:ml><r2r:ml lang="es">Título</r2r:ml>', '', 1, 5, '2013-04-15 16:42:48'),
(6, 'grsite', 'liens', 'Définition du site', '<r2r:ml lang="en">Description</r2r:ml><r2r:ml lang="pt">Definição</r2r:ml><r2r:ml lang="es">Definición</r2r:ml>', '', 1, 6, '2013-04-15 16:48:59'),
(7, 'grtitre', 'fichiers', 'Titre', '<r2r:ml lang="en">Title</r2r:ml><r2r:ml lang="pt">Títulos</r2r:ml><r2r:ml lang="es">Título</r2r:ml>', '', 1, 7, '2013-04-15 16:16:53'),
(8, 'grmultimedia', 'fichiers', 'Définition', '<r2r:ml lang="en">Description</r2r:ml><r2r:ml lang="pt">Definição</r2r:ml><r2r:ml lang="es">Definición</r2r:ml>', '', 1, 8, '2013-04-15 16:17:25'),
(9, 'grresumes', 'textes', 'Résumés', '<r2r:ml lang="en">Abstracts</r2r:ml><r2r:ml lang="pt">Resumos</r2r:ml><r2r:ml lang="es">Resúmenes</r2r:ml>', '', 1, 3, '2013-04-12 16:48:32'),
(10, 'grtitre', 'publications', 'Groupe de titre', '<r2r:ml lang="en">Title section</r2r:ml><r2r:ml lang="pt">Títulos</r2r:ml><r2r:ml lang="es">Títulos</r2r:ml>', '', 32, 1, '2013-04-11 15:22:29'),
(11, 'grgestion', 'publications', 'Gestion des publications', '<r2r:ml lang="en">Publishing options</r2r:ml><r2r:ml lang="es">Gestión de publicaciones</r2r:ml>', '', 1, 6, '2013-04-11 17:23:26'),
(12, 'grmetadonnees', 'publications', 'Groupe des métadonnées', '<r2r:ml lang="en">Metadata section</r2r:ml><r2r:ml lang="pt">Metadados</r2r:ml><r2r:ml lang="es">Metadatos</r2r:ml>', '', 32, 2, '2013-04-11 15:44:53'),
(13, 'graddenda', 'publications', 'Groupe des addenda', '<r2r:ml lang="en">Addenda section</r2r:ml><r2r:ml lang="pt">Adenda</r2r:ml><r2r:ml lang="es">Adenda</r2r:ml>', '', 32, 4, '2013-04-11 17:01:02'),
(14, 'grpersonnes', 'textes', 'Auteurs', '<r2r:ml lang="en">Authors</r2r:ml><r2r:ml lang="pt">Autores</r2r:ml><r2r:ml lang="es">Autores</r2r:ml>', '', 1, 2, '2013-04-12 16:46:16'),
(15, 'grindex', 'textes', 'Index', '<r2r:ml lang="en">Indexes</r2r:ml><r2r:ml lang="pt">Índice</r2r:ml><r2r:ml lang="es">Índice</r2r:ml>', '', 1, 5, '2013-04-12 17:23:41'),
(16, 'grgestion', 'textes', 'Gestion du document', '<r2r:ml lang="en">Document management</r2r:ml><r2r:ml lang="pt">Gestão do documento</r2r:ml><r2r:ml lang="es">Gestión del documento</r2r:ml>', '', 1, 10, '2013-04-15 10:49:49'),
(17, 'grrecension', 'textes', 'Oeuvre commentée (si ce document est un compte-rendu d\'oeuvre ou d\'ouvrage...)', '<r2r:ml lang="pt">Obra comentada (se este documento é uma recensão de obra)</r2r:ml><r2r:ml lang="es">Obra comentada (si este documento es una reseña de una obra)</r2r:ml>', '', 1, 8, '2013-04-15 10:36:23'),
(18, 'grtitre', 'textessimples', 'Titre', '<r2r:ml lang="en">Title</r2r:ml><r2r:ml lang="pt">Título</r2r:ml><r2r:ml lang="es">Título </r2r:ml>', '', 1, 10, '2013-04-15 15:23:29'),
(19, 'grtexte', 'textessimples', 'Texte', '<r2r:ml lang="en">Text</r2r:ml><r2r:ml lang="pt">Texto</r2r:ml><r2r:ml lang="es">Texto</r2r:ml>', '', 1, 11, '2013-04-15 15:24:43'),
(24, 'grdroits', 'fichiers', 'Droits', '<r2r:ml lang="en">License</r2r:ml><r2r:ml lang="pt">Direitos</r2r:ml><r2r:ml lang="es">Derechos</r2r:ml>', '', 32, 16, '2013-04-15 16:23:37'),
(25, 'grauteurs', 'liens', 'Auteurs', '<r2r:ml lang="en">Authors</r2r:ml><r2r:ml lang="pt">Autores</r2r:ml><r2r:ml lang="es">Autores</r2r:ml>', '', 32, 17, '2013-04-15 17:16:34'),
(26, 'grauteurs', 'textessimples', 'Auteurs', '<r2r:ml lang="en">Authors</r2r:ml><r2r:ml lang="pt">Autores</r2r:ml><r2r:ml lang="es">Autores</r2r:ml>', '', 32, 18, '2013-04-15 15:27:42'),
(28, 'grtitre', 'individus', 'Titre', '<r2r:ml lang="en">Title</r2r:ml><r2r:ml lang="pt">Títulos</r2r:ml><r2r:ml lang="es">Título</r2r:ml>', '', 1, 20, '2013-04-15 15:42:40'),
(30, 'grdescription', 'individus', 'Description', '<r2r:ml lang="en">Description</r2r:ml><r2r:ml lang="pt">Descrição</r2r:ml><r2r:ml lang="es">Discripción</r2r:ml>', '', 1, 21, '2013-04-15 16:03:01'),
(31, 'catalogage', 'publications', 'Elements de catalogage', '<r2r:ml lang="es">Elementos de catálogo</r2r:ml>', '', 1, 3, '2013-04-11 16:36:17'),
(32, 'grindexlivres', 'publications', 'Groupe index des livres', '<r2r:ml lang="es">Índices de libros</r2r:ml>', '', 1, 5, '2013-04-11 17:06:40'),
(34, 'grtitre', 'fichiersexternes', 'Titre', '<r2r:ml lang="en">Title</r2r:ml><r2r:ml lang="pt">Títulos</r2r:ml><r2r:ml lang="es">Título</r2r:ml>', '', 32, 22, '2013-04-15 17:25:58'),
(35, 'grdefinition', 'fichiersexternes', 'Définition', '<r2r:ml lang="pt">Definição</r2r:ml><r2r:ml lang="en">Description</r2r:ml><r2r:ml lang="es">Definición</r2r:ml>', '', 32, 23, '2013-04-15 17:26:48'),
(36, 'grdroits', 'fichiersexternes', 'Droits', '<r2r:ml lang="en">License</r2r:ml><r2r:ml lang="pt">Direitos</r2r:ml><r2r:ml lang="es">Derechos</r2r:ml>', '', 32, 24, '2013-04-15 17:30:23'),
(41, 'grdates', 'textes', 'Groupe des dates', '<r2r:ml lang="pt">Grupo de datas</r2r:ml><r2r:ml lang="en">Dates</r2r:ml><r2r:ml lang="es">Fechas </r2r:ml>', '', 32, 11, '2013-04-15 11:40:37'),
(42, 'grdates', 'publications', 'Groupe des dates', '<r2r:ml lang="pt">Grupo de datas</r2r:ml><r2r:ml lang="en">Dates</r2r:ml><r2r:ml lang="es">Grupo de fechas</r2r:ml>', '', 32, 9, '2013-04-11 17:35:55'),
(43, 'grdiffusionfichierselectroniques', 'publications', 'Diffusion des fichiers électroniques', '<r2r:ml lang="es">Difusión de archivos electrónicos</r2r:ml>', '', 32, 8, '2013-04-11 17:34:07'),
(44, 'grdates', 'fichiers', 'Groupe des dates', '<r2r:ml lang="pt">Grupo de datas</r2r:ml><r2r:ml lang="en">Dates</r2r:ml><r2r:ml lang="es">Fechas</r2r:ml>', '', 32, 17, '2013-04-15 16:24:17'),
(45, 'grdates', 'liens', 'Groupe des dates', '<r2r:ml lang="pt">Grupo de datas</r2r:ml><r2r:ml lang="en">Dates</r2r:ml><r2r:ml lang="es">Fechas</r2r:ml>', '', 32, 18, '2013-04-15 17:20:55'),
(46, 'grdates', 'textessimples', 'Groupe des dates', '<r2r:ml lang="pt">Grupo de datas</r2r:ml><r2r:ml lang="en">Dates</r2r:ml><r2r:ml lang="es">Fechas</r2r:ml>', '', 32, 19, '2013-04-15 15:28:53'),
(47, 'grdates', 'individus', 'Groupe des dates', '<r2r:ml lang="pt">Grupo de datas</r2r:ml><r2r:ml lang="en">Dates</r2r:ml><r2r:ml lang="es">Fechas</r2r:ml>', '', 32, 22, '2013-04-15 16:11:47'),
(48, 'grdates', 'fichiersexternes', 'Groupe des dates', '<r2r:ml lang="pt">Grupo de datas</r2r:ml><r2r:ml lang="en">Dates</r2r:ml><r2r:ml lang="es">Fechas</r2r:ml>', '', 32, 25, '2013-04-15 17:31:16'),
(50, 'grdefinition', 'modulesaffichage', 'Définition', '<r2r:ml lang="es">Definición</r2r:ml>', '', 1, 26, '2013-04-15 17:42:24');

#
# Dumping data for table 'types'
#

INSERT INTO #_TP_types (id, icon, type, title, altertitle, class, tpl, tplcreation, tpledition, import, display, creationstatus, search, public, gui_user_complexity, oaireferenced, rank, status, upd) VALUES (184, '', 'informations', 'Informations pratiques', '<r2r:ml lang="en">Information note</r2r:ml><r2r:ml lang="pt">Informações práticas</r2r:ml><r2r:ml lang="es">Información práctica</r2r:ml>', 'textes', 'information', 'entities', '', 1, '', -1, 1, 0, 32, 0, 12, 32, '2013-04-15 15:10:28'),
(186, '', 'collection', 'Collection', '<r2r:ml lang="en">Collection</r2r:ml><r2r:ml lang="pt">Coleção</r2r:ml><r2r:ml lang="es">Colección</r2r:ml>', 'publications', 'sommaire', 'entities', 'edition', 0, '', -1, 1, 0, 16, 0, 1, 32, '2013-04-12 15:20:03'),
(187, 'lodel/icons/volume.gif', 'livre', 'Livre', '<r2r:ml lang="en">Book</r2r:ml><r2r:ml lang="pt">Livro</r2r:ml><r2r:ml lang="es">Libro </r2r:ml>', 'publications', 'livre', 'entities', 'edition', 0, '', -1, 1, 0, 32, 0, 3, 32, '2013-04-12 15:20:19'),
(189, 'lodel/icons/rubrique_plat.gif', 'souspartie', 'Sous-partie', '<r2r:ml lang="en">Subsection</r2r:ml><r2r:ml lang="pt">Subsecção</r2r:ml><r2r:ml lang="es">subsección</r2r:ml>', 'publications', '', 'entities', 'edition', 0, 'unfolded', -1, 1, 0, 16, 0, 6, 32, '2013-04-12 16:09:15'),
(191, '', 'noticedesite', 'Notice de site', '<r2r:ml lang="en">Website presentation</r2r:ml><r2r:ml lang="pt">Ficha do website</r2r:ml><r2r:ml lang="es">Ficha del sitio web</r2r:ml>', 'liens', 'lien', 'entities', '', 0, '', -1, 1, 0, 64, 0, 16, 1, '2013-04-15 17:24:17'),
(195, '', 'individu', 'Notice biographique de membre', '<r2r:ml lang="en">Biographical presentation</r2r:ml><r2r:ml lang="pt">Nota biográfica</r2r:ml><r2r:ml lang="es">Nota biográfica</r2r:ml>', 'individus', 'individu', 'entities', '', 0, '', -1, 1, 0, 16, 0, 25, 1, '2013-04-15 16:16:26'),
(196, '', 'billet', 'Billet', '<r2r:ml lang="en">Note</r2r:ml><r2r:ml lang="pt">Post</r2r:ml><r2r:ml lang="es">Nota</r2r:ml>', 'textessimples', '', 'entities', '', 0, '', -1, 1, 0, 16, 0, 1, 1, '2013-04-15 15:39:00'),
(204, '', 'fichierannexe', 'Fichier placé en annexe', '<r2r:ml lang="en">Appended file</r2r:ml><r2r:ml lang="pt">Ficheiro anexo</r2r:ml><r2r:ml lang="es">Archivo en anexo</r2r:ml>', 'fichiers', '', 'entities', '', 0, 'advanced', -1, 1, 0, 32, 0, 7, 1, '2019-09-24 09:39:21'),
(211, '', 'source', 'Source', '<r2r:ml lang="pt">Fonte</r2r:ml><r2r:ml lang="es">Fuente</r2r:ml>', 'textes', 'article', 'entities', '', 1, '', -1, 1, 0, 64, 0, 14, 32, '2013-04-15 15:13:03'),
(212, '', 'facsimile', 'Fac-similé', '<r2r:ml lang="pt">Fac-símile</r2r:ml><r2r:ml lang="es">Facsímil</r2r:ml>', 'fichiers', '', 'entities', '', 0, 'advanced', -1, 1, 0, 32, 0, 39, 1, '2019-09-24 09:39:21'),
(217, '', 'image_annexe', 'Image distante placée en annexe', '<r2r:ml lang="pt">Imagem remota como anexo</r2r:ml><r2r:ml lang="en">Remote appended image</r2r:ml><r2r:ml lang="es">Imagen distante en anexo</r2r:ml>', 'fichiersexternes', '', 'entities', '', 0, 'advanced', -1, 1, 0, 64, 0, 44, 32, '2019-07-18 09:53:15'),
(218, '', 'videoannexe', 'Vidéo distante placée en annexe', '<r2r:ml lang="pt">Vídeo remoto como anexo</r2r:ml><r2r:ml lang="en">Remote appended video file</r2r:ml>', 'fichiersexternes', '', 'entities', '', 0, 'advanced', -1, 1, 0, 64, 0, 45, 32, '2019-07-18 09:53:21'),
(219, '', 'sonannexe', 'Document sonore distant placé en annexe', '<r2r:ml lang="pt">Ficheiro áudio remoto como anexo</r2r:ml><r2r:ml lang="en">Remote appended audio file</r2r:ml><r2r:ml lang="es">Archivo audio distante en anexo</r2r:ml>', 'fichiersexternes', '', 'entities', '', 0, 'advanced', -1, 1, 0, 64, 0, 46, 32, '2019-07-18 09:53:27'),
(220, '', 'animationannexe', 'Animation distante placée en annexe', '<r2r:ml lang="pt">Animação remota como anexo</r2r:ml><r2r:ml lang="en">Remote appended animation</r2r:ml><r2r:ml lang="es">Animación distante en anexo</r2r:ml>', 'fichiersexternes', '', 'entities', '', 0, 'advanced', -1, 1, 0, 64, 0, 47, 32, '2019-07-18 09:53:35'),
(224, '', 'preface', 'Préface', '<r2r:ml lang="es">Prefacio</r2r:ml>', 'textes', 'article', 'entities', '', 1, '', -1, 1, 0, 16, 1, 5, 32, '2013-04-15 12:32:07'),
(225, '', 'postface', 'Postface', '<r2r:ml lang="es">Epílogo</r2r:ml>', 'textes', 'article', 'entities', '', 1, '', -1, 1, 0, 16, 1, 15, 32, '2013-04-15 15:16:35'),
(226, '', 'avantpropos', 'Avant-propos', '<r2r:ml lang="en">Foreword</r2r:ml><r2r:ml lang="es">Prólogo</r2r:ml>', 'textes', 'article', 'entities', '', 1, '', -1, 1, 0, 16, 1, 4, 32, '2013-04-15 12:30:32'),
(227, '', 'bibliographie', 'Bibliographie', '<r2r:ml lang="en">Bibliography</r2r:ml><r2r:ml lang="es">Bibliografía</r2r:ml>', 'textes', 'article', 'entities', '', 1, '', -1, 1, 0, 16, 1, 16, 32, '2013-04-15 15:16:49'),
(228, '', 'index', 'Index', '<r2r:ml lang="es">Índice </r2r:ml>', 'textes', 'article', 'entities', '', 1, '', -1, 1, 0, 16, 1, 17, 32, '2013-04-15 15:17:03'),
(229, '', 'annexe', 'Annexe', '<r2r:ml lang="es">Anexo</r2r:ml>', 'textes', 'article', 'entities', '', 1, '', -1, 1, 0, 16, 1, 18, 32, '2013-04-15 15:17:24'),
(231, '', 'couverture1', '1ere de couverture', '<r2r:ml lang="es">Portada 1</r2r:ml>', 'fichiers', 'image', 'entities', '', 0, 'advanced', -1, 1, 0, 16, 0, 52, 1, '2019-09-24 09:39:21'),
(232, '', 'couverture4', '4e de couverture', '<r2r:ml lang="es">Portada 4</r2r:ml>', 'fichiers', '', 'entities', '', 0, 'advanced', -1, 1, 0, 16, 0, 53, 1, '2019-09-24 09:39:21'),
(233, '', 'tdm', 'Table de matières', '<r2r:ml lang="es">Índice de materias</r2r:ml>', 'fichiers', '', 'entities', '', 0, 'advanced', -1, 1, 0, 32, 0, 54, 1, '2019-09-24 09:39:21'),
(234, '', 'pageliminaire', 'Page liminaire', '<r2r:ml lang="es">Página de presentación</r2r:ml>', 'textes', 'article', 'entities', '', 1, '', -1, 1, 0, 16, 1, 2, 32, '2013-04-15 12:10:10'),
(235, '', 'chapitre', 'Chapitre', '<r2r:ml lang="es">Capítulo</r2r:ml>', 'textes', 'article', 'entities', '', 1, '', -1, 1, 0, 16, 1, 7, 32, '2013-04-15 12:34:36'),
(236, '', 'adressebibliographique', 'Adresse bibliographique', '<r2r:ml lang="es">Dirección bibliográfica</r2r:ml>', 'textes', 'article', 'entities', '', 1, '', -1, 1, 0, 16, 1, 1, 32, '2013-04-15 12:04:04'),
(238, '', 'accueil', 'Composition page d\'accueil', '<r2r:ml lang="es">Composición página de inicio</r2r:ml>', 'publications', '', 'entities', 'edition', 0, '', -1, 0, 0, 64, 0, 56, 1, '2013-04-12 16:33:42'),
(239, '', 'modulelivres', 'Module de livres', '<r2r:ml lang="es">Módulo de libros</r2r:ml>', 'modulesaffichage', '', 'entities', '', 0, '', -1, 0, 0, 32, 0, 57, 1, '2013-04-16 11:05:28');

#
# Dumping data for table 'persontypes'
#

INSERT INTO #_TP_persontypes (id, icon, type, title, altertitle, class, style, g_type, tpl, tplindex, gui_user_complexity, rank, status, otx, upd) VALUES (240, 'lodel/icons/auteur.gif', 'auteur', 'Auteurs', '<r2r:ml lang="en">Authors</r2r:ml><r2r:ml lang="es">Autores</r2r:ml><r2r:ml lang="pt">Autores</r2r:ml><r2r:ml lang="it">Autori</r2r:ml>', 'auteurs', 'auteur,author', 'dc.creator', 'personne', 'personnes', 32, 1, 32, '/tei:TEI/tei:teiHeader/tei:fileDesc/tei:titleStmt/tei:author', '2019-07-25 17:25:52'),
(241, '', 'traducteur', 'Traducteurs', '<r2r:ml lang="en">Translators</r2r:ml><r2r:ml lang="es">Traductores</r2r:ml><r2r:ml lang="pt">Tradutores</r2r:ml><r2r:ml lang="it">Traduttori</r2r:ml>', 'auteurs', 'traducteur,translator', 'dc.contributor', 'personne', 'personnes', 64, 2, 32, '/tei:TEI/tei:teiHeader/tei:fileDesc/tei:titleStmt/tei:editor[@role=\'translator\']', '2019-07-25 17:25:47'),
(242, '', 'directeurdelapublication', 'Directeurs de la publication', '<r2r:ml lang="en">Issue editors</r2r:ml><r2r:ml lang="es">Coordinadores de edición</r2r:ml><r2r:ml lang="pt">Organizadores</r2r:ml><r2r:ml lang="it">Direttori della pubblicazione</r2r:ml>', 'auteurs', 'directeur', '', 'personne', 'personnes', 32, 3, 32, '', '2019-07-25 17:25:42'),
(243, '', 'auteuroeuvre', 'Auteurs d’une œuvre commentée', '<r2r:ml lang="en">Authors of reviewed books</r2r:ml><r2r:ml lang="es">Autores de obra comentada</r2r:ml><r2r:ml lang="pt">Autores da obra comentada</r2r:ml><r2r:ml lang="it">Autori di un’opera commentata</r2r:ml>', 'auteurs', 'auteuroeuvre', '', 'personne', 'personnes', 64, 4, 32, '/tei:TEI/tei:text/tei:front/tei:div[@type=\'review\']/tei:p[@rend=\'review-author\']', '2019-07-25 17:25:37'),
(244, '', 'editeurscientifique', 'Éditeurs scientifiques', '<r2r:ml lang="en">Academic editors</r2r:ml><r2r:ml lang="es">Coordinadores científicos</r2r:ml><r2r:ml lang="pt">Editores científicos</r2r:ml><r2r:ml lang="it">Editori scientifici</r2r:ml>', 'auteurs', 'editeurscientifique,academiceditor', '', 'personne', 'personnes', 64, 5, 32, '/tei:TEI/tei:teiHeader/tei:fileDesc/tei:titleStmt/tei:editor[not(@role)]', '2019-07-25 17:25:29'),
(245, '', 'personnecitee', 'Personnes citées', '<r2r:ml lang="en">Persons mentioned</r2r:ml><r2r:ml lang="es">Personas citadas</r2r:ml><r2r:ml lang="pt">Pessoas citadas</r2r:ml><r2r:ml lang="it">Persone citate</r2r:ml>', 'auteurs', '', '', 'entree', 'personnes', 64, 6, 32, '', '2019-07-25 17:25:07');

#
# Dumping data for table 'entrytypes'
#

INSERT INTO #_TP_entrytypes (id, icon, type, class, title, altertitle, style, g_type, tpl, tplindex, gui_user_complexity, rank, status, flat, newbyimportallowed, edition, sort, otx, upd, lang, externalallowed) VALUES (246, '', 'motsclesfr', 'indexes', 'Mots-clés', '<r2r:ml lang="de">Mots-clés</r2r:ml><r2r:ml lang="en">Mots-clés</r2r:ml><r2r:ml lang="es">Mots-clés</r2r:ml><r2r:ml lang="fr">Mots-clés</r2r:ml><r2r:ml lang="it">Mots-clés</r2r:ml><r2r:ml lang="pt">Mots-clés</r2r:ml>', 'motscles,motcles,motscls,motsclesfr', 'dc.subject', 'entree', 'entrees', 32, 1, 32, 1, 1, 'pool', 'sortkey', '/tei:TEI/tei:teiHeader/tei:profileDesc/tei:textClass/tei:keywords[@scheme=\'keyword\']', '2019-10-23 11:24:33', 'fr', 0),
(247, '', 'motsclesen', 'indexes', 'Keywords', '<r2r:ml lang="de">Keywords</r2r:ml><r2r:ml lang="en">Keywords</r2r:ml><r2r:ml lang="es">Keywords</r2r:ml><r2r:ml lang="fr">Keywords</r2r:ml><r2r:ml lang="it">Keywords</r2r:ml><r2r:ml lang="pt">Keywords</r2r:ml>', 'keywords,motclesen', 'dc.subject', 'entree', 'entrees', 32, 2, 32, 1, 1, 'pool', 'sortkey', '/tei:TEI/tei:teiHeader/tei:profileDesc/tei:textClass/tei:keywords[@scheme=\'keyword\']', '2019-07-04 14:59:59', 'en', 0),
(248, '', 'geographie', 'indexes', 'Index géographique', '<r2r:ml lang="en">Geographical index</r2r:ml><r2r:ml lang="es">Índice geográfico</r2r:ml><r2r:ml lang="pt">Índice geográfico</r2r:ml><r2r:ml lang="it">Indice geografico</r2r:ml><r2r:ml lang="fr">Index géographique</r2r:ml><r2r:ml lang="de">Geographischer Index</r2r:ml>', 'geographie,gographie,geography', '', 'entree', 'entrees', 32, 10, 32, 0, 1, 'pool', 'rank', '/tei:TEI/tei:teiHeader/tei:profileDesc/tei:textClass/tei:keywords[@scheme=\'geographical\']', '2019-11-05 14:24:42', 'fr', 0),
(249, '', 'chrono', 'indexes', 'Index chronologique', '<r2r:ml lang="en">Chronological index</r2r:ml><r2r:ml lang="es">Índice cronológico</r2r:ml><r2r:ml lang="pt">Índice cronológico</r2r:ml><r2r:ml lang="it">Indice cronologico</r2r:ml><r2r:ml lang="de">Chronologischer Index</r2r:ml><r2r:ml lang="fr">Index chronologique</r2r:ml>', 'periode,priode,chronology', '', 'entree', 'entrees', 32, 9, 32, 0, 1, 'pool', 'rank', '/tei:TEI/tei:teiHeader/tei:profileDesc/tei:textClass/tei:keywords[@scheme=\'chronological\']', '2019-10-23 11:26:11', 'fr', 0),
(250, '', 'theme', 'indexes', 'Index thématique', '<r2r:ml lang="en">Subject index</r2r:ml><r2r:ml lang="es">Índice temático</r2r:ml><r2r:ml lang="pt">Índice temático</r2r:ml><r2r:ml lang="it">Indice tematico</r2r:ml><r2r:ml lang="fr">Index thématique</r2r:ml><r2r:ml lang="de">Thematischer Index</r2r:ml>', 'themes,thmes,subject', '', 'entree', 'entrees', 32, 11, 32, 0, 1, 'pool', 'sortkey', '/tei:TEI/tei:teiHeader/tei:profileDesc/tei:textClass/tei:keywords[@scheme=\'subject\']', '2019-10-23 11:26:42', 'fr', 0),
(251, '', 'motsclesde', 'indexes', 'Schlüsselwörter', '<r2r:ml lang="de">Schlüsselwörter</r2r:ml><r2r:ml lang="en">Schlüsselwörter</r2r:ml><r2r:ml lang="es">Schlüsselwörter</r2r:ml><r2r:ml lang="fr">Schlüsselwörter</r2r:ml><r2r:ml lang="it">Schlüsselwörter</r2r:ml><r2r:ml lang="pt">Schlüsselwörter</r2r:ml>', 'schlusselworter,motsclesde,schlagworter', 'dc.subject', 'entree', 'entrees', 32, 7, 32, 1, 1, 'pool', 'sortkey', '/tei:TEI/tei:teiHeader/tei:profileDesc/tei:textClass/tei:keywords[@scheme=\'keyword\']', '2019-10-23 11:25:59', 'de', 0),
(252, '', 'motscleses', 'indexes', 'Palabras claves', '<r2r:ml lang="de">Palabras claves</r2r:ml><r2r:ml lang="en">Palabras claves</r2r:ml><r2r:ml lang="fr">Palabras claves</r2r:ml><r2r:ml lang="es">Palabras claves</r2r:ml><r2r:ml lang="it">Palabras claves</r2r:ml><r2r:ml lang="pt">Palabras claves</r2r:ml>', 'palabrasclaves,motscleses', 'dc.subject', 'entree', 'entrees', 32, 3, 32, 1, 1, 'pool', 'sortkey', '/tei:TEI/tei:teiHeader/tei:profileDesc/tei:textClass/tei:keywords[@scheme=\'keyword\']', '2019-10-23 11:24:51', 'es', 0),
(253, '', 'coediteur', 'indexes', 'Coéditeurs', '<r2r:ml lang="en">Copublishers</r2r:ml><r2r:ml lang="es">Coeditores</r2r:ml><r2r:ml lang="pt">Co-editora</r2r:ml><r2r:ml lang="it">Coeditori</r2r:ml><r2r:ml lang="fr">Coéditeurs</r2r:ml><r2r:ml lang="de">Mitverleger</r2r:ml>', '', '', 'entree', 'entrees', 32, 12, 32, 1, 1, 'pool', 'sortkey', '', '2019-07-04 16:40:36', 'fr', 0),
(254, '', 'dossiers', 'indexes', 'Dossiers', '<r2r:ml lang="en">Selections</r2r:ml><r2r:ml lang="es">Selecciones</r2r:ml><r2r:ml lang="pt">Dossiês</r2r:ml><r2r:ml lang="it">Selezioni</r2r:ml><r2r:ml lang="de">Selektionen</r2r:ml><r2r:ml lang="fr">Dossiers</r2r:ml>', '', '', 'entree', 'entrees', 32, 8, 32, 0, 0, 'pool', 'rank', '', '2019-07-04 16:40:46', 'fr', 0),
(615, '', 'motsclesit', 'indexes', 'Parole chiave', '<r2r:ml lang="de">Parole chiave</r2r:ml><r2r:ml lang="en">Parole chiave</r2r:ml><r2r:ml lang="fr">Parole chiave</r2r:ml><r2r:ml lang="es">Parole chiave</r2r:ml><r2r:ml lang="it">Parole chiave</r2r:ml><r2r:ml lang="pt">Parole chiave</r2r:ml>', 'parolechiave,motsclesit', 'dc.subject', 'entree', 'entrees', 32, 5, 32, 1, 1, 'pool', 'sortkey', '/tei:TEI/tei:teiHeader/tei:profileDesc/tei:textClass/tei:keywords[@scheme=\'keyword\']', '2019-10-23 11:25:25', 'it', 0),
(621, '', 'motsclespt', 'indexes', 'Palavras chaves', '<r2r:ml lang="de">Palavras chaves</r2r:ml><r2r:ml lang="en">Palavras chaves</r2r:ml><r2r:ml lang="fr">Palavras chaves</r2r:ml><r2r:ml lang="es">Palavras chaves</r2r:ml><r2r:ml lang="it">Palavras chaves</r2r:ml><r2r:ml lang="pt">Palavras chaves</r2r:ml>', 'palavraschaves,motsclespt', 'dc.subject', 'entree', 'entrees', 32, 4, 32, 1, 1, 'pool', 'sortkey', '/tei:TEI/tei:teiHeader/tei:profileDesc/tei:textClass/tei:keywords[@scheme=\'keyword\']', '2019-10-23 11:25:08', 'pt', 0),
(628, '', 'funder', 'funder', 'Funder', '<r2r:ml lang="fr">Financement</r2r:ml><r2r:ml lang="es">Financiación</r2r:ml><r2r:ml lang="it">Finanziamento</r2r:ml><r2r:ml lang="de">Finanzierung</r2r:ml>', '', '', '', '', 32, 13, 32, 1, 0, 'inline', 'sortkey', '', '2019-07-05 12:24:40', 'en', 0);

#
# Dumping data for table 'entitytypes_entitytypes'
#

INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, cond) VALUES (186, 0, '*'),
(189, 189, '*'),
(189, 187, '*'),
(236, 189, '*'),
(236, 187, '*'),
(235, 189, '*'),
(235, 187, '*'),
(229, 189, '*'),
(228, 189, '*'),
(187, 186, '*'),
(234, 189, '*'),
(234, 187, '*'),
(228, 187, '*'),
(229, 187, '*'),
(227, 189, '*'),
(239, 238, '*'),
(227, 187, '*'),
(238, 0, '*'),
(225, 189, '*'),
(226, 189, '*'),
(226, 187, '*'),
(224, 189, '*'),
(225, 187, '*'),
(224, 187, '*'),
(184, 186, '*'),
(211, 187, '*'),
(211, 189, '*'),
(196, 238, '*'),
(191, 186, '*'),
(218, 229, '*'),
(218, 226, '*'),
(218, 227, '*'),
(218, 235, '*'),
(218, 228, '*'),
(218, 184, '*'),
(218, 225, '*'),
(218, 224, '*'),
(218, 211, '*'),
(219, 229, '*'),
(219, 226, '*'),
(219, 227, '*'),
(219, 235, '*'),
(219, 228, '*'),
(219, 184, '*'),
(219, 225, '*'),
(219, 224, '*'),
(219, 211, '*'),
(220, 229, '*'),
(220, 226, '*'),
(220, 227, '*'),
(220, 235, '*'),
(220, 228, '*'),
(220, 184, '*'),
(220, 225, '*'),
(220, 224, '*'),
(220, 211, '*'),
(212, 187, '*'),
(232, 187, '*'),
(233, 187, '*'),
(231, 187, '*');

#
# Dumping data for table 'characterstyles'
#


#
# Dumping data for table 'internalstyles'
#

INSERT INTO #_TP_internalstyles (id, style, surrounding, conversion, greedy, rank, status, upd, otx) VALUES (1, 'citation,quotation,quotations,quote', '-*', '<blockquote></blockquote>', 0, 1, 1, '2018-06-06 12:09:02', '//*[@rend=\'quotation\']'),
(3, 'citationbis,quotationbis', '-*', '<blockquote class="citationbis">', 0, 3, 1, '2018-06-06 12:09:02', '//*[@rend=\'quotation2\']'),
(4, 'citationter,quotationter', '-*', '<blockquote class="citationter">', 0, 4, 1, '2018-06-06 12:09:02', '//*[@rend=\'quotation3\']'),
(5, 'titreillustration,illustrationtitle', '*-', '', 0, 5, 1, '2018-06-06 12:09:02', '//*[@rend=\'figure-title\']'),
(6, 'legendeillustration,illustrationcaption', '-*', '', 0, 6, 1, '2018-06-06 12:09:02', '//*[@rend=\'figure-legend\']'),
(10, 'code', '*-', '', 0, 10, 1, '2011-04-14 15:38:45', '//*[@rend=\'code\']'),
(11, 'question', '*-', '', 0, 11, 1, '2011-04-14 15:38:45', '//*[@rend=\'question\']'),
(12, 'reponse,answer', '*-', '', 0, 12, 1, '2018-06-06 12:09:02', '//*[@rend=\'answer\']'),
(15, 'section3', '*-', '<h3>', 0, 15, 1, '2011-04-14 15:38:45', '//tei:head[@subtype=\'level3\']'),
(16, 'section4', '*-', '<h4>', 0, 16, 1, '2011-04-14 15:38:45', '//tei:head[@subtype=\'level4\']'),
(17, 'section5', '*-', '<h5>', 0, 17, 1, '2011-04-14 15:38:45', '//tei:head[@subtype=\'level5\']'),
(18, 'section6', '*-', '<h6>', 0, 18, 1, '2011-04-14 15:38:45', '//tei:head[@subtype=\'level6\']'),
(19, 'section1', '*-', '<h1>', 0, 13, 1, '2011-04-14 15:38:45', '//tei:head[@subtype=\'level1\']'),
(20, 'separateur,sparateur,separator', '*-', '', 0, 19, 1, '2018-06-06 12:09:02', '//*[@rend=\'break\']'),
(21, 'paragraphesansretrait,notindentedparagraph', '*-', '', 0, 20, 1, '2018-06-06 12:09:02', '//*[@rend=\'noindent\']'),
(22, 'epigraphe,pigraphe,addendum', '*-', '', 0, 21, 1, '2018-06-06 12:09:02', '//*[@rend=\'epigraph\']'),
(23, 'section2', '*-', '<h2>', 0, 14, 1, '2011-04-14 15:38:45', '//tei:head[@subtype=\'level2\']'),
(27, 'terme', '-*', '', 0, 25, 1, '2006-03-02 09:52:27', ''),
(28, 'definitiondeterme', '-*', '', 0, 26, 1, '2006-03-02 09:52:37', ''),
(32, 'creditillustration,crditillustration,creditsillustration,crditsillustration,illustrationcredits', '-*', '', 0, 30, 1, '2018-06-06 12:09:02', '//*[@rend=\'figure-license\']'),
(34, 'encadre,box', '-*', '', 0, 32, 1, '2018-06-06 12:09:02', '//*[@rend=\'box\']');
DELETE FROM #_TP_optiongroups;
# # Database: 'lodelbooks_me-books-dist'# 
#
# Dumping data for table 'optiongroups'
#

INSERT INTO #_TP_optiongroups (id, idparent, name, title, altertitle, comment, logic, exportpolicy, rank, status, upd) VALUES (2, 0, 'metadonneessite', 'Métadonnées du site', '<r2r:ml lang="en">Website metadata</r2r:ml><r2r:ml lang="pt">Metadados do website</r2r:ml><r2r:ml lang="es">Metadatos del sitio web</r2r:ml>', '', '', 1, 2, 1, '2013-04-16 11:08:08'),
(12, 0, 'optionsgenerales', 'Options générales', '<r2r:ml lang="pt">Opções gerais</r2r:ml><r2r:ml lang="es">Opciones generales</r2r:ml>', '', '', 1, 11, 1, '2013-04-16 11:14:03'),
(13, 0, 'optionsaffichage', 'Options d\'affichage', '<r2r:ml lang="en">Display options</r2r:ml><r2r:ml lang="pt">Opções de visualização</r2r:ml><r2r:ml lang="es">Opciones de visualización</r2r:ml>', '', '', 1, 12, 1, '2013-04-16 11:15:36');
DELETE FROM #_TP_options;
# # Database: 'lodelbooks_me-books-dist'# 
#
# Dumping data for table 'options'
#

INSERT INTO #_TP_options (id, idgroup, name, title, type, defaultvalue, comment, userrights, rank, status, upd, edition, editionparams) VALUES (14, 2, 'droitsauteur', 'Droits d\'auteur par défaut', 'mltext', '', '', 30, 12, 1, '2013-04-16 11:10:25', 'editable', ''),
(18, 2, 'courrielabuse', 'Courriel abuse', 'tinytext', 'abuse@openedition.org', '', 40, 16, 1, '2019-07-01 15:21:06', 'editable', ''),
(27, 2, 'langueprincipale', 'Langue principale du site', 'lang', 'fr', '', 40, 18, 1, '2019-07-01 15:21:06', 'editable', ''),
(33, 2, 'imagehabillee', 'Habillage des images', 'boolean', '', '', 40, 26, 32, '2013-04-16 11:12:10', 'editable', ''),
(34, 2, 'pdf', 'PDF automatique', 'boolean', '', '', 40, 27, 1, '2013-04-16 11:12:35', 'editable', ''),
(35, 2, 'pdf_electronique', 'PDF électronique', 'boolean', '', '', 40, 28, 1, '2013-04-16 11:13:38', 'editable', ''),
(14197, 13, 'couleurliens', 'Couleur des liens', 'color', '', '', 40, 29, 1, '2013-04-16 11:15:59', 'editable', ''),
(14198, 13, 'logoprincipal', 'Logo affiché dans le bandeau', 'image', '', '', 40, 30, 1, '2013-04-16 12:03:18', 'editable', ''),
(14200, 12, 'fondcouvertureauto', 'Image de fond de couverture automatique', 'image', '', '', 40, 32, 1, '2013-04-16 11:14:29', 'editable', ''),
(14201, 13, 'liensrecommandes', 'Liens recommandés', 'tinytext', '', '', 40, 33, 1, '2013-04-16 12:03:59', 'editable', ''),
(14205, 12, 'urllibrairiepapierediteur', 'URL de la librairie papier de l\'éditeur', 'url', '', '', 40, 37, 1, '2013-04-16 11:15:06', 'editable', ''),
(14206, 13, 'affichageremerciements', 'Affichage des remerciements', 'list', 'top', '', 40, 38, 1, '2013-07-30 13:43:42', 'editable', 'top,bottom'),
(14207, 12, 'languesutilisees', 'Langues utilisées (hors alphabets latin, grec et cyrillique), format ISO-639-2', 'tinytext', '', '', 40, 39, 1, '2013-10-11 09:30:59', 'display', ''),
(14208, 13, 'codepublishing', 'Publication de code informatique', 'boolean', '', '', 40, 40, 1, '2014-01-02 15:13:05', 'editable', ''),
(14209, 12, 'librairiesexclues', 'Librairies exclues', 'list', '', '', 40, 41, 1, '2014-01-10 14:18:02', 'checkbox', 'i6doc,placedeslibraires,lcdpu,leslibraires,decitre,mollat,amazon.fr,amazon.com'),
(14212, 12, 'emversion', 'Version du modèle éditorial', 'tinytext', '1.0.0', '', 40, 42, 1, '2019-12-05 17:42:52', 'display', '');
# # Database: 'lodelbooks_me-books-dist'# 
# --------------------------------------------------------

#
# Table structure for table 'textes'
#

DROP TABLE IF EXISTS #_TP_textes;
CREATE TABLE #_TP_textes (
  identity int(10) unsigned NOT NULL,
  titre text DEFAULT NULL,
  surtitre text DEFAULT NULL,
  soustitre text DEFAULT NULL,
  texte longtext DEFAULT NULL,
  notesbaspage longtext DEFAULT NULL,
  annexe longtext DEFAULT NULL,
  bibliographie longtext DEFAULT NULL,
  pagination tinytext DEFAULT NULL,
  langue char(5) DEFAULT NULL,
  prioritaire tinyint(4) DEFAULT NULL,
  addendum text DEFAULT NULL,
  ndlr text DEFAULT NULL,
  commentaireinterne text DEFAULT NULL,
  dedicace text DEFAULT NULL,
  documentcliquable tinyint(4) DEFAULT NULL,
  `resume` text DEFAULT NULL,
  altertitre text DEFAULT NULL,
  titreoeuvre text DEFAULT NULL,
  noticebibliooeuvre text DEFAULT NULL,
  datepublicationoeuvre tinytext DEFAULT NULL,
  ndla text DEFAULT NULL,
  alterfichier tinytext DEFAULT NULL,
  notefin longtext DEFAULT NULL,
  imagehabillee tinyint(4) DEFAULT NULL,
  datemisenligne date DEFAULT NULL,
  dateacceslibre date DEFAULT NULL,
  fichierreference tinyint(4) DEFAULT NULL,
  vignettesimple tinyint(4) DEFAULT NULL,
  langueoriginale char(5) DEFAULT NULL,
  fichierwordnumerise tinytext DEFAULT NULL,
  remerciements text DEFAULT NULL,
  PRIMARY KEY (identity),
  KEY index_identity (identity)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

# --------------------------------------------------------

#
# Table structure for table 'publications'
#

DROP TABLE IF EXISTS #_TP_publications;
CREATE TABLE #_TP_publications (
  identity int(10) unsigned NOT NULL,
  titre text DEFAULT NULL,
  surtitre text DEFAULT NULL,
  soustitre text DEFAULT NULL,
  commentaireinterne text DEFAULT NULL,
  prioritaire tinyint(4) DEFAULT NULL,
  datepubli date DEFAULT NULL,
  datepublipapier date DEFAULT NULL,
  noticebiblio text DEFAULT NULL,
  introduction text DEFAULT NULL,
  ndlr text DEFAULT NULL,
  historique text DEFAULT NULL,
  paraitre tinyint(4) DEFAULT NULL,
  integralite tinyint(4) DEFAULT NULL,
  numero tinytext DEFAULT NULL,
  langue char(5) DEFAULT NULL,
  altertitre text DEFAULT NULL,
  urlpublicationediteur text DEFAULT NULL,
  descriptionouvrage text DEFAULT NULL,
  issn tinytext DEFAULT NULL,
  lieuedition tinytext DEFAULT NULL,
  anneeedition tinytext DEFAULT NULL,
  nombrepages tinytext DEFAULT NULL,
  formatlivre tinytext DEFAULT NULL,
  prix tinytext DEFAULT NULL,
  liencommercial text DEFAULT NULL,
  racinemets tinyint(4) DEFAULT NULL,
  datemisenligne date DEFAULT NULL,
  dateacceslibre date DEFAULT NULL,
  prixcommercialisationnumero text DEFAULT NULL,
  langueoriginale char(5) DEFAULT NULL,
  ocr tinyint(4) DEFAULT NULL,
  languesecondaire char(5) DEFAULT NULL,
  issnelectronique tinytext DEFAULT NULL,
  `resume` text DEFAULT NULL,
  isbnhtml tinytext DEFAULT NULL,
  fondcouvertureauto tinytext DEFAULT NULL,
  extrait text DEFAULT NULL,
  PRIMARY KEY (identity),
  KEY index_identity (identity)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

# --------------------------------------------------------

#
# Table structure for table 'fichiers'
#

DROP TABLE IF EXISTS #_TP_fichiers;
CREATE TABLE #_TP_fichiers (
  identity int(10) unsigned NOT NULL,
  titre text DEFAULT NULL,
  document tinytext DEFAULT NULL,
  description text DEFAULT NULL,
  legende text DEFAULT NULL,
  credits tinytext DEFAULT NULL,
  vignette tinytext DEFAULT NULL,
  datepubli date DEFAULT NULL,
  datemisenligne date DEFAULT NULL,
  dateacceslibre date DEFAULT NULL,
  PRIMARY KEY (identity),
  KEY index_identity (identity)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

# --------------------------------------------------------

#
# Table structure for table 'liens'
#

DROP TABLE IF EXISTS #_TP_liens;
CREATE TABLE #_TP_liens (
  identity int(10) unsigned NOT NULL,
  titre text DEFAULT NULL,
  url text DEFAULT NULL,
  urlfil text DEFAULT NULL,
  texte text DEFAULT NULL,
  capturedecran tinytext DEFAULT NULL,
  nombremaxitems int(11) DEFAULT NULL,
  vignette tinytext DEFAULT NULL,
  altertitre text DEFAULT NULL,
  datemisenligne date DEFAULT NULL,
  dateacceslibre date DEFAULT NULL,
  PRIMARY KEY (identity),
  KEY index_identity (identity)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

# --------------------------------------------------------

#
# Table structure for table 'textessimples'
#

DROP TABLE IF EXISTS #_TP_textessimples;
CREATE TABLE #_TP_textessimples (
  identity int(10) unsigned NOT NULL,
  titre tinytext DEFAULT NULL,
  texte text DEFAULT NULL,
  url text DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  altertitre text DEFAULT NULL,
  datemisenligne date DEFAULT NULL,
  dateacceslibre date DEFAULT NULL,
  PRIMARY KEY (identity),
  KEY index_identity (identity)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

# --------------------------------------------------------

#
# Table structure for table 'auteurs'
#

DROP TABLE IF EXISTS #_TP_auteurs;
CREATE TABLE #_TP_auteurs (
  idperson int(10) unsigned NOT NULL,
  nomfamille tinytext DEFAULT NULL,
  prenom tinytext DEFAULT NULL,
  PRIMARY KEY (idperson),
  KEY index_idperson (idperson)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

# --------------------------------------------------------

#
# Table structure for table 'entities_auteurs'
#

DROP TABLE IF EXISTS #_TP_entities_auteurs;
CREATE TABLE #_TP_entities_auteurs (
  idrelation int(10) unsigned NOT NULL,
  prefix tinytext DEFAULT NULL,
  affiliation tinytext DEFAULT NULL,
  fonction tinytext DEFAULT NULL,
  description text DEFAULT NULL,
  courriel text DEFAULT NULL,
  site text DEFAULT NULL,
  PRIMARY KEY (idrelation),
  KEY index_idrelation (idrelation)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

# --------------------------------------------------------

#
# Table structure for table 'indexes'
#

DROP TABLE IF EXISTS #_TP_indexes;
CREATE TABLE #_TP_indexes (
  identry int(10) unsigned NOT NULL,
  nom text DEFAULT NULL,
  definition text DEFAULT NULL,
  mlnom text DEFAULT NULL,
  prioritaire tinyint(4) DEFAULT NULL,
  PRIMARY KEY (identry),
  KEY index_identry (identry)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

# --------------------------------------------------------

#
# Table structure for table 'entities_indexes'
#

DROP TABLE IF EXISTS #_TP_entities_indexes;
CREATE TABLE #_TP_entities_indexes (
  idrelation int(10) unsigned NOT NULL,
  PRIMARY KEY (idrelation),
  KEY index_idrelation (idrelation)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

# --------------------------------------------------------

#
# Table structure for table 'individus'
#

DROP TABLE IF EXISTS #_TP_individus;
CREATE TABLE #_TP_individus (
  identity int(10) unsigned NOT NULL,
  nom tinytext DEFAULT NULL,
  prenom tinytext DEFAULT NULL,
  email text DEFAULT NULL,
  siteweb text DEFAULT NULL,
  description text DEFAULT NULL,
  accroche text DEFAULT NULL,
  adresse text DEFAULT NULL,
  telephone tinytext DEFAULT NULL,
  photographie tinytext DEFAULT NULL,
  datemisenligne date DEFAULT NULL,
  dateacceslibre date DEFAULT NULL,
  PRIMARY KEY (identity),
  KEY index_identity (identity)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

# --------------------------------------------------------

#
# Table structure for table 'fichiersexternes'
#

DROP TABLE IF EXISTS #_TP_fichiersexternes;
CREATE TABLE #_TP_fichiersexternes (
  identity int(10) unsigned NOT NULL,
  titre tinytext DEFAULT NULL,
  object text DEFAULT NULL,
  description text DEFAULT NULL,
  vignette tinytext DEFAULT NULL,
  legende text DEFAULT NULL,
  datepubli date DEFAULT NULL,
  urlaccesmedia text DEFAULT NULL,
  urlmedia text DEFAULT NULL,
  credits tinytext DEFAULT NULL,
  datemisenligne date DEFAULT NULL,
  dateacceslibre date DEFAULT NULL,
  PRIMARY KEY (identity),
  KEY index_identity (identity)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

# --------------------------------------------------------

#
# Table structure for table 'modulesaffichage'
#

DROP TABLE IF EXISTS #_TP_modulesaffichage;
CREATE TABLE #_TP_modulesaffichage (
  identity int(10) unsigned NOT NULL,
  titre text DEFAULT NULL,
  altertitre text DEFAULT NULL,
  affichage text DEFAULT NULL,
  idcontainer double DEFAULT NULL,
  nbelementsmax double DEFAULT NULL,
  politiqueacces text DEFAULT NULL,
  ordre text DEFAULT NULL,
  PRIMARY KEY (identity),
  KEY index_identity (identity)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

# --------------------------------------------------------

#
# Table structure for table 'funder'
#

DROP TABLE IF EXISTS #_TP_funder;
CREATE TABLE #_TP_funder (
  identry int(10) unsigned NOT NULL,
  fundername text DEFAULT NULL,
  funderid tinytext DEFAULT NULL,
  PRIMARY KEY (identry)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

# --------------------------------------------------------

#
# Table structure for table 'entities_funder'
#

DROP TABLE IF EXISTS #_TP_entities_funder;
CREATE TABLE #_TP_entities_funder (
  idrelation int(10) unsigned NOT NULL,
  grantnumber text DEFAULT NULL,
  PRIMARY KEY (idrelation)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
